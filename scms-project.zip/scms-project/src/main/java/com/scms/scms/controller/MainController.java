package com.scms.scms.controller;

import com.scms.scms.model.Admin;
import com.scms.scms.model.PlacementTpo;
import com.scms.scms.model.Student;
import com.scms.scms.model.Teacher;
import com.scms.scms.repository.AdminRepository;
import com.scms.scms.repository.PlacementTpoRepository;
import com.scms.scms.repository.StudentRepository;
import com.scms.scms.repository.TeacherRepository;
import com.scms.scms.service.PasswordProtectionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class MainController {

    @Autowired private StudentRepository studentRepository;
    @Autowired private TeacherRepository teacherRepository;
    @Autowired private AdminRepository adminRepository;
    @Autowired private PlacementTpoRepository placementTpoRepository;
    @Autowired private PasswordProtectionService passwordProtectionService;

    @GetMapping("/")
    public String home() {
        return "home/home";
    }

    @PostMapping("/register")
    public String register(
            @RequestParam String name,
            @RequestParam String email,
            @RequestParam String password,
            RedirectAttributes redirectAttributes) {

        String cleanName = name == null ? "" : name.trim();
        String cleanEmail = email == null ? "" : email.trim();

        if (cleanName.isBlank() || cleanEmail.isBlank() || password == null || password.isBlank()) {
            redirectAttributes.addFlashAttribute("error", "All fields are required!");
            redirectAttributes.addFlashAttribute("showRegister", true);
            return "redirect:/";
        }

        if (studentRepository.findByEmail(cleanEmail) != null
                || teacherRepository.findByEmail(cleanEmail) != null
                || adminRepository.findByEmail(cleanEmail) != null) {
            redirectAttributes.addFlashAttribute("error", "Email already registered!");
            redirectAttributes.addFlashAttribute("showRegister", true);
            return "redirect:/";
        }

        try {
            Student s = new Student();
            s.setName(cleanName);
            s.setEmail(cleanEmail);
            s.setPassword(passwordProtectionService.encode(password.trim()));
            s.setCourse("General");
            studentRepository.save(s);

            redirectAttributes.addFlashAttribute("success", "Registered successfully! Please login.");
            redirectAttributes.addFlashAttribute("showLogin", true);
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Registration failed: " + e.getMessage());
            redirectAttributes.addFlashAttribute("showRegister", true);
        }

        return "redirect:/";
    }

    @PostMapping("/login")
    public String login(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String cleanEmail = email == null ? "" : email.trim();
        String cleanPassword = password == null ? "" : password.trim();

        if (cleanEmail.isBlank() || cleanPassword.isBlank()) {
            redirectAttributes.addFlashAttribute("errorLogin", "Email and password are required!");
            redirectAttributes.addFlashAttribute("showLogin", true);
            return "redirect:/";
        }

        Admin admin = adminRepository.findByEmail(cleanEmail);
        if (admin != null && passwordProtectionService.matches(cleanPassword, admin.getPassword())) {
            upgradeLegacyPasswordIfNeeded(admin, cleanPassword);
            session.setAttribute("loggedInUser", admin.getEmail());
            session.setAttribute("userRole", "ADMIN");
            return "redirect:/admin-dashboard";
        }

        Teacher teacher = teacherRepository.findByEmail(cleanEmail);
        if (teacher != null && passwordProtectionService.matches(cleanPassword, teacher.getPassword())) {
            upgradeLegacyPasswordIfNeeded(teacher, cleanPassword);
            session.setAttribute("loggedInUser", teacher.getEmail());
            session.setAttribute("userRole", "TEACHER");
            return "redirect:/teacher-dashboard";
        }

        PlacementTpo placementTpo = placementTpoRepository.findByEmail(cleanEmail);
        if (placementTpo != null && passwordProtectionService.matches(cleanPassword, placementTpo.getPassword())) {
            upgradeLegacyPasswordIfNeeded(placementTpo, cleanPassword);
            session.setAttribute("loggedInUser", placementTpo.getEmail());
            session.setAttribute("userRole", "PLACEMENT_TPO");
            return "redirect:/placement-dashboard";
        }

        Student student = studentRepository.findByEmail(cleanEmail);
        if (student != null && passwordProtectionService.matches(cleanPassword, student.getPassword())) {
            upgradeLegacyPasswordIfNeeded(student, cleanPassword);
            session.setAttribute("loggedInUser", student.getEmail());
            session.setAttribute("userRole", "STUDENT");
            return "redirect:/student-dashboard";
        }

        redirectAttributes.addFlashAttribute("errorLogin", "Invalid email or password!");
        redirectAttributes.addFlashAttribute("showLogin", true);
        return "redirect:/";
    }

    @GetMapping("/login")
    public String loginPage(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("showLogin", true);
        return "redirect:/";
    }

    @GetMapping("/register")
    public String registerPage(RedirectAttributes redirectAttributes) {
        redirectAttributes.addFlashAttribute("showRegister", true);
        return "redirect:/";
    }

    @GetMapping("/login-student")
    public String logoutStudent(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("showLogin", true);
        return "redirect:/";
    }

    @GetMapping("/login-teacher")
    public String logoutTeacher(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("showLogin", true);
        return "redirect:/";
    }

    @GetMapping("/login-admin")
    public String logoutAdmin(HttpSession session, RedirectAttributes redirectAttributes) {
        session.invalidate();
        redirectAttributes.addFlashAttribute("showLogin", true);
        return "redirect:/";
    }

    @GetMapping("/overview")
    public String overview() {
        return "redirect:/#overview";
    }

    @GetMapping("/courses")
    public String courses() {
        return "redirect:/#courses";
    }

    @GetMapping("/contact")
    public String contact() {
        return "redirect:/#contact";
    }

    private void upgradeLegacyPasswordIfNeeded(Admin admin, String rawPassword) {
        if (passwordProtectionService.needsUpgrade(admin.getPassword())) {
            admin.setPassword(passwordProtectionService.encode(rawPassword));
            adminRepository.save(admin);
        }
    }

    private void upgradeLegacyPasswordIfNeeded(Teacher teacher, String rawPassword) {
        if (passwordProtectionService.needsUpgrade(teacher.getPassword())) {
            teacher.setPassword(passwordProtectionService.encode(rawPassword));
            teacherRepository.save(teacher);
        }
    }

    private void upgradeLegacyPasswordIfNeeded(PlacementTpo placementTpo, String rawPassword) {
        if (passwordProtectionService.needsUpgrade(placementTpo.getPassword())) {
            placementTpo.setPassword(passwordProtectionService.encode(rawPassword));
            placementTpoRepository.save(placementTpo);
        }
    }

    private void upgradeLegacyPasswordIfNeeded(Student student, String rawPassword) {
        if (passwordProtectionService.needsUpgrade(student.getPassword())) {
            student.setPassword(passwordProtectionService.encode(rawPassword));
            studentRepository.save(student);
        }
    }
}
