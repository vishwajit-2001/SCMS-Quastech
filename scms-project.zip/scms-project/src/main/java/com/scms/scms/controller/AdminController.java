package com.scms.scms.controller;

import com.scms.scms.model.*;
import com.scms.scms.repository.*;
import com.scms.scms.service.PasswordProtectionService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.servlet.http.HttpSession;

import java.io.File;
import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    @Autowired private StudentRepository   studentRepo;
    @Autowired private TeacherRepository   teacherRepo;
    @Autowired private ClassRoomRepository classRepo;
    @Autowired private TimetableRepository timetableRepo;
    @Autowired private AdminRepository     adminRepo;
    @Autowired private PasswordProtectionService passwordProtectionService;

    private static final String UPLOAD_DIR_STUDENTS =
            System.getProperty("user.dir") + "/src/main/resources/static/uploads/students/";

    private static final String UPLOAD_DIR_TEACHERS =
            System.getProperty("user.dir") + "/src/main/resources/static/uploads/teachers/";

    // ── Auto academic year e.g. "2025-26" ──
    private String currentAcademicYear() {
        int year  = LocalDate.now().getYear();
        int month = LocalDate.now().getMonthValue();
        int start = (month >= 6) ? year : year - 1;
        return start + "-" + String.valueOf(start + 1).substring(2);
    }

    // ── Get logged-in admin from session ──
    private Admin getLoggedAdmin(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        if (email == null) return null;
        return adminRepo.findByEmail(email);
    }

    // ── Helper: add all admin attributes to model ──
    private void addAdminAttributes(Model model, Admin admin) {
        model.addAttribute("adminName",   admin.getName());
        model.addAttribute("adminEmail",  admin.getEmail());
        model.addAttribute("collegeName", admin.getCollegeName());
        model.addAttribute("adminRole",   admin.getRole());
        model.addAttribute("adminPhone",  admin.getPhone());
    }

    // ── Helper: blank → null ──
    private String blankToNull(String value) {
        return (value == null || value.isBlank()) ? null : value.strip();
    }

    // ── Helper: total fees by course ──
    private double feesForCourse(String course) {
        if (course == null) return 30000;
        return switch (course) {
            case "MCA"    -> 80000;
            case "BCA"    -> 60000;
            case "BSc CS" -> 50000;
            case "MSc CS" -> 70000;
            case "BSC IT" -> 90000;
            default       -> 30000;
        };
    }

    // ── Helper: save photo ──
    private String savePhoto(MultipartFile file, String uploadDir) {
        String ct = file.getContentType();
        if (ct == null || !(ct.equals("image/jpeg") || ct.equals("image/png")
                || ct.equals("image/webp") || ct.equals("image/gif")))
            return null;
        if (file.getSize() > 2 * 1024 * 1024) return null;

        File dir = new File(uploadDir);
        if (!dir.exists() && !dir.mkdirs()) {
            log.error("Failed to create upload directory: {}", uploadDir);
            return null;
        }

        String original = file.getOriginalFilename();
        String ext = (original != null && original.contains("."))
                ? original.substring(original.lastIndexOf(".")) : ".jpg";
        String fileName = UUID.randomUUID() + ext;

        try {
            Files.copy(file.getInputStream(),
                    Paths.get(uploadDir + fileName),
                    StandardCopyOption.REPLACE_EXISTING);
            return uploadDir.contains("teachers")
                    ? "/uploads/teachers/" + fileName
                    : "/uploads/students/" + fileName;
        } catch (IOException e) {
            log.error("Failed to save photo to {}: {}", uploadDir, e.getMessage(), e);
            return null;
        }
    }

    // ═══════════════════════════════════════════════
    // DASHBOARD
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-dashboard")
    public String dashboard(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<Student>   students = studentRepo.findByAdmin(admin);
        List<Teacher>   teachers = teacherRepo.findByAdmin(admin);
        List<ClassRoom> classes  = classRepo.findByAdmin(admin);

        model.addAttribute("totalStudents", students.size());
        model.addAttribute("totalTeachers", teachers.size());
        model.addAttribute("totalClasses",  classes.size());
        model.addAttribute("students",      students);
        model.addAttribute("teachers",      teachers);
        addAdminAttributes(model, admin);
        return "admin/admin-dashboard";
    }

    // ═══════════════════════════════════════════════
    // ADD STUDENT
    // ═══════════════════════════════════════════════
    @GetMapping("/add-student")
    public String addStudentPage(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<ClassRoom> classes = classRepo.findByAdmin(admin);
        List<String> courses = classes.stream()
                .map(ClassRoom::getCourse).filter(c -> c != null && !c.isBlank())
                .distinct().sorted().collect(Collectors.toList());

        model.addAttribute("classes",      classes);
        model.addAttribute("courses",      courses);
        model.addAttribute("academicYear", currentAcademicYear());
        addAdminAttributes(model, admin);
        return "admin/add-student";
    }

    @PostMapping("/add-student")
    public String saveStudent(
            @RequestParam("name")                                     String name,
            @RequestParam("email")                                    String email,
            @RequestParam("password")                                 String password,
            @RequestParam("course")                                   String course,

            @RequestParam(value = "academicYear",   required = false) String academicYear,
            @RequestParam(value = "semester",       required = false) String semester,
            @RequestParam(value = "degree",         required = false) String degree,
            @RequestParam(value = "sectionName",    required = false) String sectionName,
            @RequestParam(value = "medium",         required = false) String medium,
            @RequestParam(value = "classRoom.id",   required = false) Long classId,

            @RequestParam(value = "rollNo",          required = false) String rollNo,
            @RequestParam(value = "enrollmentNo",    required = false) String enrollmentNo,
            @RequestParam(value = "registrationNo",  required = false) String registrationNo,
            @RequestParam(value = "prnNumber",       required = false) String prnNumber,
            @RequestParam(value = "abcNumber",       required = false) String abcNumber,

            @RequestParam(value = "gender",          required = false) String gender,
            @RequestParam(value = "dob",             required = false) String dobStr,
            @RequestParam(value = "bloodGroup",      required = false) String bloodGroup,
            @RequestParam(value = "religion",        required = false) String religion,
            @RequestParam(value = "admissionDate",   required = false) String admissionDateStr,
            @RequestParam(value = "casteName",       required = false) String casteName,
            @RequestParam(value = "category",        required = false) String category,

            @RequestParam(value = "fatherName",      required = false) String fatherName,
            @RequestParam(value = "motherName",      required = false) String motherName,
            @RequestParam(value = "guardianName",    required = false) String guardianName,

            @RequestParam(value = "aadharNumber",    required = false) String aadharNumber,
            @RequestParam(value = "panCardNumber",   required = false) String panCardNumber,
            @RequestParam(value = "voterId",         required = false) String voterId,
            @RequestParam(value = "eidNumber",       required = false) String eidNumber,

            @RequestParam(value = "bankName",        required = false) String bankName,
            @RequestParam(value = "bankAccNo",       required = false) String bankAccNo,
            @RequestParam(value = "ifscCode",        required = false) String ifscCode,
            @RequestParam(value = "micrNumber",      required = false) String micrNumber,

            @RequestParam(value = "photo",           required = false) MultipartFile photoFile,

            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        if (studentRepo.findByEmail(email) != null) {
            model.addAttribute("error", "Email already exists!");
            model.addAttribute("classes",      classRepo.findByAdmin(admin));
            model.addAttribute("academicYear", currentAcademicYear());
            addAdminAttributes(model, admin);
            return "admin/add-student";
        }

        Student s = new Student();
        s.setName(name);
        s.setEmail(email);
        s.setPassword(passwordProtectionService.encode(password));
        s.setCourse(course);

        s.setAcademicYear((academicYear != null && !academicYear.isBlank())
                ? academicYear : currentAcademicYear());
        s.setSemester(blankToNull(semester));
        s.setDegree(blankToNull(degree));
        s.setSectionName(blankToNull(sectionName));
        s.setMedium(blankToNull(medium));

        s.setRollNo(blankToNull(rollNo));
        s.setEnrollmentNo(blankToNull(enrollmentNo));
        s.setRegistrationNo(blankToNull(registrationNo));
        s.setPrnNumber(blankToNull(prnNumber));
        s.setAbcNumber(blankToNull(abcNumber));

        s.setGender(blankToNull(gender));
        s.setBloodGroup(blankToNull(bloodGroup));
        s.setReligion(blankToNull(religion));
        s.setCasteName(blankToNull(casteName));
        s.setCategory(blankToNull(category));

        if (dobStr != null && !dobStr.isBlank()) {
            try { s.setDob(LocalDate.parse(dobStr)); } catch (Exception ignored) {}
        }
        if (admissionDateStr != null && !admissionDateStr.isBlank()) {
            try { s.setAdmissionDate(LocalDate.parse(admissionDateStr)); } catch (Exception ignored) {}
        }

        s.setFatherName(blankToNull(fatherName));
        s.setMotherName(blankToNull(motherName));
        s.setGuardianName(blankToNull(guardianName));

        s.setAadharNumber(blankToNull(aadharNumber));
        s.setPanCardNumber(panCardNumber != null ? panCardNumber.toUpperCase().strip() : null);
        s.setVoterId(blankToNull(voterId));
        s.setEidNumber(blankToNull(eidNumber));

        s.setBankName(blankToNull(bankName));
        s.setBankAccNo(blankToNull(bankAccNo));
        s.setIfscCode(ifscCode != null ? ifscCode.toUpperCase().strip() : null);
        s.setMicrNumber(blankToNull(micrNumber));

        if (classId != null) {
            classRepo.findById(classId).ifPresent(cls -> {
                s.setClassRoom(cls);
                if (s.getSemester() == null && cls.getSemester() != null) {
                    s.setSemester("Sem" + cls.getSemester());
                }
            });
        }

        if (photoFile != null && !photoFile.isEmpty()) {
            String savedPath = savePhoto(photoFile, UPLOAD_DIR_STUDENTS);
            if (savedPath == null) {
                model.addAttribute("error", "Photo upload failed — only JPG/PNG/WEBP allowed (max 2 MB).");
                model.addAttribute("classes",      classRepo.findByAdmin(admin));
                model.addAttribute("academicYear", currentAcademicYear());
                addAdminAttributes(model, admin);
                return "admin/add-student";
            }
            s.setPhoto(savedPath);
        }

        double total = feesForCourse(course);
        s.setTotalFees(total);
        s.setPaidFees(0.0);
        s.setPendingFees(total);

        s.setAdmin(admin);
        studentRepo.save(s);
        return "redirect:/admin-students";
    }

    // ═══════════════════════════════════════════════
    // VIEW STUDENTS
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-students")
    public String viewStudents(
            @RequestParam(required = false) String course,
            @RequestParam(required = false) String semester,
            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<Student> all      = studentRepo.findByAdmin(admin);
        List<Student> filtered = all;

        if (course != null && !course.isEmpty())
            filtered = filtered.stream()
                    .filter(s -> s.getCourse() != null && s.getCourse().equalsIgnoreCase(course))
                    .collect(Collectors.toList());

        if (semester != null && !semester.isEmpty())
            filtered = filtered.stream()
                    .filter(s -> s.getSemester() != null && s.getSemester().equalsIgnoreCase(semester))
                    .collect(Collectors.toList());

        model.addAttribute("students",         filtered);
        model.addAttribute("totalStudents",    all.size());
        model.addAttribute("mcaCount",  all.stream().filter(s -> "MCA".equalsIgnoreCase(s.getCourse())).count());
        model.addAttribute("bcaCount",  all.stream().filter(s -> "BCA".equalsIgnoreCase(s.getCourse())).count());
        model.addAttribute("bscCount",  all.stream().filter(s -> "BSc CS".equalsIgnoreCase(s.getCourse())).count());
        model.addAttribute("mscCount",  all.stream().filter(s -> "MSc CS".equalsIgnoreCase(s.getCourse())).count());
        model.addAttribute("selectedCourse",   course);
        model.addAttribute("selectedSemester", semester);
        addAdminAttributes(model, admin);
        return "admin/admin-students";
    }

    // ═══════════════════════════════════════════════
    // DELETE STUDENT
    // ═══════════════════════════════════════════════
    @GetMapping("/delete-student/{id}")
    public String deleteStudent(@PathVariable Long id, HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        studentRepo.deleteById(id);
        return "redirect:/admin-students";
    }

    // ═══════════════════════════════════════════════
    // ADD TEACHER
    // ═══════════════════════════════════════════════
    @GetMapping("/add-teacher")
    public String addTeacherPage(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("classes", classRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/add-teacher";
    }

    @PostMapping("/add-teacher")
    public String saveTeacher(
            @RequestParam("name")                                         String name,
            @RequestParam("email")                                        String email,
            @RequestParam("password")                                     String password,
            @RequestParam("subject")                                      String subject,

            @RequestParam(value = "gender",            required = false)  String gender,
            @RequestParam(value = "dob",               required = false)  String dobStr,
            @RequestParam(value = "bloodGroup",        required = false)  String bloodGroup,
            @RequestParam(value = "phone",             required = false)  String phone,
            @RequestParam(value = "altPhone",          required = false)  String altPhone,
            @RequestParam(value = "maritalStatus",     required = false)  String maritalStatus,
            @RequestParam(value = "religion",          required = false)  String religion,
            @RequestParam(value = "casteName",         required = false)  String casteName,
            @RequestParam(value = "category",          required = false)  String category,
            @RequestParam(value = "address",           required = false)  String address,
            @RequestParam(value = "city",              required = false)  String city,
            @RequestParam(value = "state",             required = false)  String state,

            @RequestParam(value = "designation",       required = false)  String designation,
            @RequestParam(value = "employeeId",        required = false)  String employeeId,
            @RequestParam(value = "joiningDate",       required = false)  String joiningDateStr,
            @RequestParam(value = "experience",        required = false)  String experience,
            @RequestParam(value = "employmentType",    required = false)  String employmentType,
            @RequestParam(value = "salary",            required = false)  Double salary,
            @RequestParam(value = "specialization",    required = false)  String specialization,
            @RequestParam(value = "department",        required = false)  String department,
            @RequestParam(value = "status",            required = false)  String status,
            @RequestParam(value = "classRoom.id",      required = false)  Long classId,

            @RequestParam(value = "qualification",         required = false) String qualification,
            @RequestParam(value = "degreeSpecialization",  required = false) String degreeSpecialization,
            @RequestParam(value = "university",            required = false) String university,
            @RequestParam(value = "yearOfPassing",         required = false) Integer yearOfPassing,
            @RequestParam(value = "publications",          required = false) Integer publications,

            @RequestParam(value = "aadharNumber",      required = false)  String aadharNumber,
            @RequestParam(value = "panCardNumber",     required = false)  String panCardNumber,
            @RequestParam(value = "voterId",           required = false)  String voterId,
            @RequestParam(value = "passportNumber",    required = false)  String passportNumber,

            @RequestParam(value = "bankName",          required = false)  String bankName,
            @RequestParam(value = "bankAccNo",         required = false)  String bankAccNo,
            @RequestParam(value = "ifscCode",          required = false)  String ifscCode,
            @RequestParam(value = "pfNumber",          required = false)  String pfNumber,

            @RequestParam(value = "emergencyContactName", required = false) String emergencyContactName,
            @RequestParam(value = "emergencyRelation",    required = false) String emergencyRelation,
            @RequestParam(value = "emergencyPhone",       required = false) String emergencyPhone,

            @RequestParam(value = "photo",             required = false)  MultipartFile photoFile,

            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        if (teacherRepo.findByEmail(email) != null) {
            model.addAttribute("error", "A teacher with this email already exists!");
            model.addAttribute("classes", classRepo.findByAdmin(admin));
            addAdminAttributes(model, admin);
            return "admin/add-teacher";
        }

        Teacher t = new Teacher();
        t.setName(name);
        t.setEmail(email);
        t.setPassword(passwordProtectionService.encode(password));
        t.setSubject(subject);

        t.setGender(blankToNull(gender));
        t.setBloodGroup(blankToNull(bloodGroup));
        t.setPhone(blankToNull(phone));
        t.setAltPhone(blankToNull(altPhone));
        t.setMaritalStatus(blankToNull(maritalStatus));
        t.setReligion(blankToNull(religion));
        t.setCasteName(blankToNull(casteName));
        t.setCategory(blankToNull(category));
        t.setAddress(blankToNull(address));
        t.setCity(blankToNull(city));
        t.setState(blankToNull(state));

        if (dobStr != null && !dobStr.isBlank()) {
            try { t.setDob(LocalDate.parse(dobStr)); } catch (Exception ignored) {}
        }

        t.setDesignation(blankToNull(designation));
        t.setEmployeeId(blankToNull(employeeId));
        t.setEmploymentType(blankToNull(employmentType));
        t.setSpecialization(blankToNull(specialization));
        t.setExperience(blankToNull(experience));
        t.setDepartment(blankToNull(department));
        t.setStatus(status != null && !status.isBlank() ? status : "Active");
        if (salary != null) t.setSalary(salary);

        if (joiningDateStr != null && !joiningDateStr.isBlank()) {
            try { t.setJoiningDate(LocalDate.parse(joiningDateStr)); } catch (Exception ignored) {}
        }

        if (classId != null) classRepo.findById(classId).ifPresent(t::setClassRoom);

        t.setQualification(blankToNull(qualification));
        t.setDegreeSpecialization(blankToNull(degreeSpecialization));
        t.setUniversity(blankToNull(university));
        if (yearOfPassing != null) t.setYearOfPassing(yearOfPassing);
        if (publications  != null) t.setPublications(publications);

        t.setAadharNumber(blankToNull(aadharNumber));
        t.setPanCardNumber(panCardNumber != null ? panCardNumber.toUpperCase().strip() : null);
        t.setVoterId(blankToNull(voterId));
        t.setPassportNumber(passportNumber != null ? passportNumber.toUpperCase().strip() : null);

        t.setBankName(blankToNull(bankName));
        t.setBankAccNo(blankToNull(bankAccNo));
        t.setIfscCode(ifscCode != null ? ifscCode.toUpperCase().strip() : null);
        t.setPfNumber(blankToNull(pfNumber));

        t.setEmergencyContactName(blankToNull(emergencyContactName));
        t.setEmergencyRelation(blankToNull(emergencyRelation));
        t.setEmergencyPhone(blankToNull(emergencyPhone));

        if (photoFile != null && !photoFile.isEmpty()) {
            String savedPath = savePhoto(photoFile, UPLOAD_DIR_TEACHERS);
            if (savedPath == null) {
                model.addAttribute("error", "Photo upload failed — only JPG/PNG/WEBP allowed (max 2 MB).");
                model.addAttribute("classes", classRepo.findByAdmin(admin));
                addAdminAttributes(model, admin);
                return "admin/add-teacher";
            }
            t.setPhoto(savedPath);
        }

        t.setAdmin(admin);
        teacherRepo.save(t);
        return "redirect:/admin-teachers";
    }

    // ═══════════════════════════════════════════════
    // VIEW TEACHERS
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-teachers")
    public String viewTeachers(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        List<Teacher> teachers = teacherRepo.findByAdmin(admin);
        model.addAttribute("teachers",      teachers);
        model.addAttribute("totalTeachers", teachers.size());
        addAdminAttributes(model, admin);
        return "admin/admin-teachers";
    }

    @GetMapping("/delete-teacher/{id}")
    public String deleteTeacher(@PathVariable Long id, HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        teacherRepo.deleteById(id);
        return "redirect:/admin-teachers";
    }

    // ═══════════════════════════════════════════════
    // ADD CLASS
    // ═══════════════════════════════════════════════
    @GetMapping("/add-class")
    public String addClassPage(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("teachers", teacherRepo.findByAdmin(admin));
        model.addAttribute("classes",  classRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/add-class";
    }

    @PostMapping("/add-class")
    public String saveClass(
            @RequestParam("course")                                String course,
            @RequestParam(value = "year",      required = false)  String year,
            @RequestParam(value = "semester",  required = false)  Integer semester,
            @RequestParam(value = "section",   required = false)  String section,
            @RequestParam(value = "room",      required = false)  String room,
            @RequestParam(value = "batch",     required = false)  String batch,
            @RequestParam(value = "teacherId", required = false)  Long teacherId,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        ClassRoom c = new ClassRoom();
        c.setCourse(course);
        c.setYear(blankToNull(year));
        c.setSemester(semester);
        c.setSection(blankToNull(section));
        c.setRoom(blankToNull(room));

        if (batch != null && !batch.isBlank()) {
            c.setBatch(batch.strip());
        } else if (year != null && !year.isBlank()) {
            c.setBatch(year + course.replaceAll("\\s+", ""));
        }

        StringBuilder nameBuilder = new StringBuilder(course);
        if (year     != null && !year.isBlank())    nameBuilder.append("-").append(year);
        if (semester != null)                        nameBuilder.append("-Sem").append(semester);
        if (section  != null && !section.isBlank()) nameBuilder.append("-").append(section);
        c.setName(nameBuilder.toString());

        if (teacherId != null) teacherRepo.findById(teacherId).ifPresent(c::setTeacher);
        c.setAdmin(admin);
        classRepo.save(c);
        return "redirect:/view-classes";
    }

    // ═══════════════════════════════════════════════
    // VIEW CLASSES
    // ═══════════════════════════════════════════════
    @GetMapping("/view-classes")
    public String viewClasses(
            @RequestParam(required = false) String course,
            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<ClassRoom> all = classRepo.findByAdmin(admin);
        List<ClassRoom> filtered = (course != null && !course.isBlank())
                ? all.stream().filter(c -> course.equalsIgnoreCase(c.getCourse())).collect(Collectors.toList())
                : all;

        List<String> courses = all.stream()
                .map(ClassRoom::getCourse).filter(c -> c != null && !c.isBlank())
                .distinct().sorted().collect(Collectors.toList());

        model.addAttribute("classes",        filtered);
        model.addAttribute("courses",        courses);
        model.addAttribute("selectedCourse", course);
        addAdminAttributes(model, admin);
        return "admin/view-classes";
    }

    // ═══════════════════════════════════════════════
    // TIMETABLE
    // ═══════════════════════════════════════════════
    @GetMapping("/add-timetable")
    public String addTimetablePage(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("classes",  classRepo.findByAdmin(admin));
        model.addAttribute("teachers", teacherRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/add-timetable";
    }

    @PostMapping("/add-timetable")
    public String saveTimetable(
            @RequestParam String day,
            @RequestParam String startTime,
            @RequestParam String endTime,
            @RequestParam String subject,
            @RequestParam String room,
            @RequestParam Long classId,
            @RequestParam Long teacherId,
            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        for (Timetable entry : timetableRepo.findByAdmin(admin)) {
            if (entry.getTeacher() != null
                    && entry.getTeacher().getId().equals(teacherId)
                    && entry.getDay().equalsIgnoreCase(day)
                    && entry.getStartTime().equals(startTime)) {
                model.addAttribute("error",
                        "⚠️ Teacher clash! Already has a class at " + startTime + " on " + day);
                model.addAttribute("classes",  classRepo.findByAdmin(admin));
                model.addAttribute("teachers", teacherRepo.findByAdmin(admin));
                addAdminAttributes(model, admin);
                return "admin/add-timetable";
            }
        }

        Timetable t = new Timetable();
        t.setDay(day);
        t.setStartTime(startTime);
        t.setEndTime(endTime);
        t.setSubject(subject);
        t.setRoom(room);
        t.setClassRoom(classRepo.findById(classId).orElse(null));
        t.setTeacher(teacherRepo.findById(teacherId).orElse(null));
        t.setAdmin(admin);
        timetableRepo.save(t);
        return "redirect:/view-timetable";
    }

    @GetMapping("/view-timetable")
    public String viewTimetable(
            @RequestParam(required = false) Long classId,
            @RequestParam(required = false) String course,
            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<ClassRoom> allClasses = classRepo.findByAdmin(admin);

        List<Timetable> timetable;
        if (classId != null) {
            timetable = timetableRepo.findByAdminAndClassRoom(
                    admin, classRepo.findById(classId).orElse(null));
        } else {
            timetable = timetableRepo.findByAdmin(admin);
        }

        List<String> courses = allClasses.stream()
                .map(ClassRoom::getCourse).filter(c -> c != null && !c.isBlank())
                .distinct().sorted().collect(Collectors.toList());

        model.addAttribute("timetable",       timetable);
        model.addAttribute("classes",         allClasses);
        model.addAttribute("courses",         courses);
        model.addAttribute("selectedClassId", classId);
        model.addAttribute("selectedCourse",  course);
        addAdminAttributes(model, admin);
        return "admin/view-timetable";
    }

    @GetMapping("/delete-timetable/{id}")
    public String deleteTimetable(@PathVariable Long id, HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        timetableRepo.deleteById(id);
        return "redirect:/view-timetable";
    }

    @GetMapping("/smart-timetable")
    public String smartTimetable(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("timetable", timetableRepo.findByAdmin(admin));
        model.addAttribute("classes",   classRepo.findByAdmin(admin));
        model.addAttribute("teachers",  teacherRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/smart-timetable";
    }

    // ═══════════════════════════════════════════════
    // FEES
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-fees")
    public String adminFees(
            @RequestParam(required = false) String course,
            @RequestParam(required = false) String semester,
            @RequestParam(required = false) String search,
            Model model,
            HttpSession session) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        List<Student> all      = studentRepo.findByAdmin(admin);
        List<Student> filtered = all;

        if (course != null && !course.isEmpty())
            filtered = filtered.stream()
                    .filter(s -> s.getCourse() != null && s.getCourse().equalsIgnoreCase(course))
                    .collect(Collectors.toList());

        if (semester != null && !semester.isEmpty())
            filtered = filtered.stream()
                    .filter(s -> s.getSemester() != null && s.getSemester().equalsIgnoreCase(semester))
                    .collect(Collectors.toList());

        if (search != null && !search.isBlank()) {
            String q = search.toLowerCase().strip();
            filtered = filtered.stream()
                    .filter(s -> (s.getName()  != null && s.getName().toLowerCase().contains(q))
                            || (s.getEmail() != null && s.getEmail().toLowerCase().contains(q)))
                    .collect(Collectors.toList());
        }

        double totalCollected = all.stream().mapToDouble(s -> s.getPaidFees()    != null ? s.getPaidFees()    : 0.0).sum();
        double totalPending   = all.stream().mapToDouble(s -> s.getPendingFees() != null ? s.getPendingFees() : 0.0).sum();
        double totalFees      = all.stream().mapToDouble(s -> s.getTotalFees()   != null ? s.getTotalFees()   : 0.0).sum();
        int    collectionRate = (totalFees > 0) ? (int) ((totalCollected / totalFees) * 100) : 0;

        List<String> courses   = all.stream().map(Student::getCourse)
                .filter(c -> c != null && !c.isBlank()).distinct().sorted().collect(Collectors.toList());
        List<String> semesters = all.stream().map(Student::getSemester)
                .filter(s -> s != null && !s.isBlank()).distinct().sorted().collect(Collectors.toList());

        model.addAttribute("students",         filtered);
        model.addAttribute("totalStudents",    all.size());
        model.addAttribute("totalCollected",   (long) totalCollected);
        model.addAttribute("totalPending",     (long) totalPending);
        model.addAttribute("totalFees",        (long) totalFees);
        model.addAttribute("collectionRate",   collectionRate);
        model.addAttribute("courses",          courses);
        model.addAttribute("semesters",        semesters);
        model.addAttribute("selectedCourse",   course);
        model.addAttribute("selectedSemester", semester);
        model.addAttribute("search",           search);
        addAdminAttributes(model, admin);
        return "admin/admin-fees";
    }

    @PostMapping("/update-fees/{id}")
    public String updateFees(@PathVariable Long id,
                             @RequestParam double paidAmount,
                             HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        studentRepo.findById(id).ifPresent(student -> {
            double newPaid = (student.getPaidFees() != null ? student.getPaidFees() : 0.0) + paidAmount;
            double total   =  student.getTotalFees() != null ? student.getTotalFees() : 0.0;
            student.setPaidFees(newPaid);
            student.setPendingFees(Math.max(0, total - newPaid));
            studentRepo.save(student);
        });
        return "redirect:/admin-fees";
    }

    @PostMapping("/pay-fees")
    public String payFees(@RequestParam Long studentId,
                          @RequestParam double amount,
                          HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        studentRepo.findById(studentId).ifPresent(student -> {
            double newPaid = (student.getPaidFees() != null ? student.getPaidFees() : 0.0) + amount;
            double total   =  student.getTotalFees() != null ? student.getTotalFees() : 0.0;
            student.setPaidFees(newPaid);
            student.setPendingFees(Math.max(0, total - newPaid));
            studentRepo.save(student);
        });
        return "redirect:/admin-fees?success=Payment Successful";
    }

    @PostMapping("/set-fees")
    public String setFees(@RequestParam String courseName, HttpSession session) {
        if (getLoggedAdmin(session) == null) return "redirect:/login-admin";
        double fee = feesForCourse(courseName);
        studentRepo.findAll().stream()
                .filter(s -> s.getCourse() != null && s.getCourse().equalsIgnoreCase(courseName))
                .filter(s -> s.getTotalFees() == null || s.getTotalFees() == 0)
                .forEach(s -> {
                    s.setTotalFees(fee);
                    s.setPaidFees(0.0);
                    s.setPendingFees(fee);
                    studentRepo.save(s);
                });
        return "redirect:/admin-fees?success=Fees Applied Successfully";
    }

    // ═══════════════════════════════════════════════
    // NOTIFICATIONS
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-notifications")
    public String adminNotifications(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("students", studentRepo.findByAdmin(admin));
        model.addAttribute("teachers", teacherRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/admin-notifications";
    }

    // ═══════════════════════════════════════════════
    // PROFILE — View Only (no edit form)
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-profile")
    public String adminProfile(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("admin",         admin);
        model.addAttribute("adminId",       admin.getId());
        model.addAttribute("totalStudents", studentRepo.findByAdmin(admin).size());
        model.addAttribute("totalTeachers", teacherRepo.findByAdmin(admin).size());
        addAdminAttributes(model, admin);
        return "admin/admin-profile";
    }

    // ═══════════════════════════════════════════════
    // CHANGE PASSWORD — Admin can ONLY change password
    // ═══════════════════════════════════════════════
    @PostMapping("/change-admin-password")
    public String changeAdminPassword(
            @RequestParam String currentPassword,
            @RequestParam String newPassword,
            @RequestParam String confirmPassword,
            HttpSession session,
            Model model) {

        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";

        // 1. Current password must be correct
        if (!passwordProtectionService.matches(currentPassword, admin.getPassword())) {
            model.addAttribute("passError", "Current password is incorrect!");
            model.addAttribute("admin",         admin);
            model.addAttribute("adminId",       admin.getId());
            model.addAttribute("totalStudents", studentRepo.findByAdmin(admin).size());
            model.addAttribute("totalTeachers", teacherRepo.findByAdmin(admin).size());
            addAdminAttributes(model, admin);
            return "admin/admin-profile";
        }

        // 2. New password must meet minimum length
        if (newPassword.length() < 8) {
            model.addAttribute("passError", "New password must be at least 8 characters!");
            model.addAttribute("admin",         admin);
            model.addAttribute("adminId",       admin.getId());
            model.addAttribute("totalStudents", studentRepo.findByAdmin(admin).size());
            model.addAttribute("totalTeachers", teacherRepo.findByAdmin(admin).size());
            addAdminAttributes(model, admin);
            return "admin/admin-profile";
        }

        // 3. New password and confirm password must match
        if (!newPassword.equals(confirmPassword)) {
            model.addAttribute("passError", "New passwords do not match!");
            model.addAttribute("admin",         admin);
            model.addAttribute("adminId",       admin.getId());
            model.addAttribute("totalStudents", studentRepo.findByAdmin(admin).size());
            model.addAttribute("totalTeachers", teacherRepo.findByAdmin(admin).size());
            addAdminAttributes(model, admin);
            return "admin/admin-profile";
        }

        // 4. New password must not be the same as current
        if (passwordProtectionService.isSamePassword(newPassword, admin.getPassword())) {
            model.addAttribute("passError", "New password cannot be the same as current password!");
            model.addAttribute("admin",         admin);
            model.addAttribute("adminId",       admin.getId());
            model.addAttribute("totalStudents", studentRepo.findByAdmin(admin).size());
            model.addAttribute("totalTeachers", teacherRepo.findByAdmin(admin).size());
            addAdminAttributes(model, admin);
            return "admin/admin-profile";
        }

        // ✅ All checks passed — save new password
        admin.setPassword(passwordProtectionService.encode(newPassword));
        adminRepo.save(admin);
        return "redirect:/admin-profile?success=Password changed successfully!";
    }

    // ═══════════════════════════════════════════════
    // REPORTS
    // ═══════════════════════════════════════════════
    @GetMapping("/admin-reports")
    public String adminReports(Model model, HttpSession session) {
        Admin admin = getLoggedAdmin(session);
        if (admin == null) return "redirect:/login-admin";
        model.addAttribute("students", studentRepo.findByAdmin(admin));
        model.addAttribute("teachers", teacherRepo.findByAdmin(admin));
        model.addAttribute("classes",  classRepo.findByAdmin(admin));
        addAdminAttributes(model, admin);
        return "admin/admin-reports";
    }
}//phone number remove kerna hai dasbhord se admin ke abhi admin_profile.html me me phone number show ho rha hai
