package com.scms.scms.controller;

import com.scms.scms.model.Admin;
import com.scms.scms.model.ClassRoom;
import com.scms.scms.model.Student;
import com.scms.scms.model.Teacher;
import com.scms.scms.model.Timetable;
import com.scms.scms.repository.StudentRepository;
import com.scms.scms.repository.TimetableRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.text.NumberFormat;
import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.TextStyle;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

@Controller
public class StudentController {

    private static final Locale INDIA = new Locale("en", "IN");
    private static final NumberFormat CURRENCY_FORMAT = NumberFormat.getNumberInstance(INDIA);
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("dd MMM yyyy");
    private static final DateTimeFormatter DATE_WITH_DAY_FORMAT = DateTimeFormatter.ofPattern("EEEE, dd MMM yyyy");
    private static final List<String> WORKING_DAYS = List.of(
            "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
    );

    @Autowired private StudentRepository studentRepository;
    @Autowired private TimetableRepository timetableRepository;

    @GetMapping("/student-dashboard")
    public String dashboard(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/dashboard";
    }

    @GetMapping("/exam-results")
    public String examResults(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        model.addAttribute("resultsAvailable", false);
        return "student/connected/exam-results";
    }

    @GetMapping("/timetable")
    public String timetable(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/timetable";
    }

    @GetMapping("/subjects")
    public String subjects(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/subjects";
    }

    @GetMapping("/attendance")
    public String attendance(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        model.addAttribute("attendanceAvailable", false);
        return "student/connected/attendance";
    }

    @GetMapping("/assignments")
    public String assignments(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        model.addAttribute("assignmentsAvailable", false);
        return "student/connected/assignments";
    }

    @GetMapping({"/profile", "/student-profile"})
    public String profile(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/profile";
    }

    @GetMapping("/fees")
    public String fees(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/fees";
    }

    @GetMapping("/notifications")
    public String notifications(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        return "student/connected/notifications";
    }

    @GetMapping("/student-marks")
    public String marks(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        model.addAttribute("resultsAvailable", false);
        return "student/connected/student-marks";
    }

    @GetMapping("/student-attendance")
    public String stuAtt(Model model, HttpSession session) {
        Student student = prepareStudentPage(model, session);
        if (student == null) return "redirect:/login";
        model.addAttribute("attendanceAvailable", false);
        return "student/connected/student-attendance";
    }

    private Student prepareStudentPage(Model model, HttpSession session) {
        Student student = getLoggedStudent(session);
        if (student == null) return null;

        StudentPortalData portalData = buildPortalData(student);

        model.addAttribute("student", student);
        model.addAttribute("studentName", defaultText(student.getName(), "Student"));
        model.addAttribute("studentCourse", defaultText(student.getCourse(), "Student"));
        model.addAttribute("studentEmail", defaultText(student.getEmail(), "Not available"));
        model.addAttribute("studentId", portalData.studentId());
        model.addAttribute("studentRollNo", portalData.rollNo());
        model.addAttribute("studentInitials", portalData.initials());
        model.addAttribute("studentSemesterLabel", portalData.semesterLabel());
        model.addAttribute("studentSectionLabel", portalData.sectionLabel());
        model.addAttribute("studentAcademicYear", portalData.academicYear());
        model.addAttribute("studentClassLabel", portalData.classLabel());
        model.addAttribute("studentClassMentor", portalData.classMentor());
        model.addAttribute("studentPrimaryRoom", portalData.primaryRoom());
        model.addAttribute("studentPhoto", student.getPhoto());
        model.addAttribute("studentMobile", "Not provided");
        model.addAttribute("studentDob", formatDate(student.getDob()));
        model.addAttribute("studentAdmissionDate", formatDate(student.getAdmissionDate()));
        model.addAttribute("studentGender", defaultText(student.getGender(), "Not provided"));
        model.addAttribute("studentBloodGroup", defaultText(student.getBloodGroup(), "Not provided"));
        model.addAttribute("studentCategory", defaultText(student.getCategory(), "Not provided"));
        model.addAttribute("studentReligion", defaultText(student.getReligion(), "Not provided"));
        model.addAttribute("studentAadharMasked", maskValue(student.getAadharNumber(), 4));
        model.addAttribute("studentFatherName", defaultText(student.getFatherName(), "Not provided"));
        model.addAttribute("studentMotherName", defaultText(student.getMotherName(), "Not provided"));
        model.addAttribute("studentGuardianName", defaultText(student.getGuardianName(), "Not provided"));
        model.addAttribute("studentBankName", defaultText(student.getBankName(), "Not provided"));
        model.addAttribute("studentBankAccMasked", maskValue(student.getBankAccNo(), 4));
        model.addAttribute("studentIfscCode", defaultText(student.getIfscCode(), "Not provided"));
        model.addAttribute("studentPrnNumber", defaultText(student.getPrnNumber(), "Not provided"));
        model.addAttribute("studentEnrollmentNo", defaultText(student.getEnrollmentNo(), "Not provided"));
        model.addAttribute("studentRegistrationNo", defaultText(student.getRegistrationNo(), "Not provided"));
        model.addAttribute("studentAbcNumber", defaultText(student.getAbcNumber(), "Not provided"));
        model.addAttribute("studentStatus", "Active");

        model.addAttribute("subjectCount", portalData.subjectSummaries().size());
        model.addAttribute("weeklyClassCount", portalData.allTimetableEntries().size());
        model.addAttribute("todayScheduleCount", portalData.todaySchedule().size());
        model.addAttribute("activeAcademicDays", portalData.activeAcademicDays());
        model.addAttribute("todayCompletedCount", portalData.todayCompletedCount());
        model.addAttribute("todayUpcomingCount", portalData.todayUpcomingCount());
        model.addAttribute("todayCurrentSlot", portalData.currentSlot());
        model.addAttribute("todayNextSlot", portalData.nextSlot());
        model.addAttribute("subjectSummaries", portalData.subjectSummaries());
        model.addAttribute("todaySchedule", portalData.todaySchedule());
        model.addAttribute("weeklySchedule", portalData.weeklySchedule());
        model.addAttribute("weeklyTimetableRows", portalData.weeklyTimetableRows());
        model.addAttribute("workingDayNames", WORKING_DAYS);
        model.addAttribute("todayLabel", portalData.todayLabel());
        model.addAttribute("todayDayKey", portalData.todayDayKey());
        model.addAttribute("todayFullDate", portalData.todayFullDate());

        model.addAttribute("feesTotal", portalData.totalFees());
        model.addAttribute("feesPaid", portalData.paidFees());
        model.addAttribute("feesPending", portalData.pendingFees());
        model.addAttribute("feesTotalFormatted", portalData.totalFeesFormatted());
        model.addAttribute("feesPaidFormatted", portalData.paidFeesFormatted());
        model.addAttribute("feesPendingFormatted", portalData.pendingFeesFormatted());
        model.addAttribute("feesPaidPercentage", portalData.paidPercentage());
        model.addAttribute("feesDueStatus", portalData.pendingFees() > 0 ? "Pending" : "Cleared");

        model.addAttribute("studentNotifications", portalData.notifications());
        model.addAttribute("dashboardNotifications", portalData.notifications().stream().limit(4).toList());
        model.addAttribute("notificationCount", portalData.notifications().size());

        return student;
    }

    private StudentPortalData buildPortalData(Student student) {
        List<Timetable> timetableEntries = loadStudentTimetable(student);
        LinkedHashMap<String, List<TimetableSlotView>> weeklySchedule = buildWeeklySchedule(timetableEntries);
        String todayName = currentDayName();
        List<TimetableSlotView> todaySchedule = new ArrayList<>(weeklySchedule.getOrDefault(todayName, List.of()));
        List<SubjectSummaryView> subjectSummaries = buildSubjectSummaries(timetableEntries);
        DayScheduleInsight dayScheduleInsight = buildDayScheduleInsight(todaySchedule);

        double totalFees = safeNumber(student.getTotalFees());
        double paidFees = safeNumber(student.getPaidFees());
        double pendingFees = student.getPendingFees() != null
                ? student.getPendingFees()
                : Math.max(totalFees - paidFees, 0);
        int paidPercentage = totalFees > 0 ? (int) Math.round((paidFees / totalFees) * 100) : 0;
        long activeAcademicDays = weeklySchedule.values().stream()
                .filter(daySlots -> !daySlots.isEmpty())
                .count();

        List<StudentNotificationView> notifications =
                buildNotifications(student, todaySchedule, subjectSummaries, pendingFees, dayScheduleInsight);

        return new StudentPortalData(
                resolveStudentId(student),
                defaultText(student.getRollNo(), "Not assigned"),
                buildStudentInitials(student.getName()),
                buildSemesterLabel(student),
                buildSectionLabel(student),
                defaultText(student.getAcademicYear(), "Not assigned"),
                buildClassLabel(student),
                resolveClassMentor(student),
                resolvePrimaryRoom(student, dayScheduleInsight.currentSlot()),
                todayName,
                todayName.substring(0, 3).toLowerCase(Locale.ENGLISH),
                LocalDate.now().format(DATE_WITH_DAY_FORMAT),
                totalFees,
                paidFees,
                pendingFees,
                formatCurrency(totalFees),
                formatCurrency(paidFees),
                formatCurrency(pendingFees),
                paidPercentage,
                (int) activeAcademicDays,
                dayScheduleInsight.completedCount(),
                dayScheduleInsight.upcomingCount(),
                dayScheduleInsight.currentSlot(),
                dayScheduleInsight.nextSlot(),
                weeklySchedule,
                buildWeeklyTimetableRows(weeklySchedule),
                todaySchedule,
                timetableEntries,
                subjectSummaries,
                notifications
        );
    }

    private Student getLoggedStudent(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        String role = (String) session.getAttribute("userRole");
        if (email == null || (role != null && !"STUDENT".equalsIgnoreCase(role))) {
            return null;
        }
        return studentRepository.findByEmail(email);
    }

    private List<Timetable> loadStudentTimetable(Student student) {
        ClassRoom classRoom = student.getClassRoom();
        if (classRoom == null) {
            return List.of();
        }

        Admin admin = student.getAdmin();
        List<Timetable> entries = (admin != null)
                ? timetableRepository.findByAdminAndClassRoom(admin, classRoom)
                : List.of();

        if (entries.isEmpty()) {
            entries = timetableRepository.findByClassRoom(classRoom);
        }

        if (entries.isEmpty()) {
            entries = timetableRepository.findAll().stream()
                    .filter(t -> t.getClassRoom() != null && Objects.equals(t.getClassRoom().getId(), classRoom.getId()))
                    .toList();
        }

        return entries.stream()
                .sorted(Comparator
                        .comparingInt((Timetable t) -> dayOrderIndex(t.getDay()))
                        .thenComparing(t -> parseTime(t.getStartTime())))
                .toList();
    }

    private LinkedHashMap<String, List<TimetableSlotView>> buildWeeklySchedule(List<Timetable> entries) {
        LinkedHashMap<String, List<TimetableSlotView>> weekly = new LinkedHashMap<>();
        for (String day : WORKING_DAYS) {
            weekly.put(day, new ArrayList<>());
        }

        for (Timetable entry : entries) {
            String day = normalizeDay(entry.getDay());
            if (!WORKING_DAYS.contains(day)) {
                continue;
            }
            weekly.get(day).add(new TimetableSlotView(
                    day,
                    defaultText(entry.getStartTime(), "--"),
                    defaultText(entry.getEndTime(), "--"),
                    defaultText(entry.getSubject(), "Subject not assigned"),
                    resolveTeacherName(entry.getTeacher()),
                    defaultText(entry.getRoom(), "Room not assigned"),
                    buildSubjectClass(entry.getSubject())
            ));
        }

        weekly.values().forEach(list -> list.sort(Comparator.comparing(slot -> parseTime(slot.getStartTime()))));
        return weekly;
    }

    private List<WeeklyTimetableRowView> buildWeeklyTimetableRows(LinkedHashMap<String, List<TimetableSlotView>> weeklySchedule) {
        LinkedHashMap<String, WeeklyTimetableRowBuilder> rows = new LinkedHashMap<>();

        for (String day : WORKING_DAYS) {
            for (TimetableSlotView slot : weeklySchedule.getOrDefault(day, List.of())) {
                String key = slot.getStartTime() + "|" + slot.getEndTime();
                WeeklyTimetableRowBuilder builder = rows.computeIfAbsent(
                        key,
                        value -> new WeeklyTimetableRowBuilder(slot.getStartTime(), slot.getEndTime())
                );
                builder.put(day, slot);
            }
        }

        return rows.values().stream()
                .sorted(Comparator.comparing(row -> parseTime(row.startTime())))
                .map(WeeklyTimetableRowBuilder::build)
                .toList();
    }

    private List<SubjectSummaryView> buildSubjectSummaries(List<Timetable> entries) {
        Map<String, SubjectSummaryViewBuilder> grouped = new LinkedHashMap<>();

        for (Timetable entry : entries) {
            String subjectName = defaultText(entry.getSubject(), "Unassigned Subject");
            SubjectSummaryViewBuilder builder = grouped.computeIfAbsent(
                    subjectName + "|" + resolveTeacherName(entry.getTeacher()),
                    key -> new SubjectSummaryViewBuilder(
                            subjectName,
                            resolveTeacherName(entry.getTeacher()),
                            buildSubjectClass(entry.getSubject())
                    )
            );
            builder.addEntry(
                    normalizeDay(entry.getDay()),
                    defaultText(entry.getStartTime(), "--"),
                    defaultText(entry.getEndTime(), "--")
            );
            builder.setRoom(defaultText(entry.getRoom(), "Room not assigned"));
        }

        List<SubjectSummaryView> subjects = new ArrayList<>();
        for (SubjectSummaryViewBuilder builder : grouped.values()) {
            subjects.add(builder.build());
        }
        return subjects;
    }

    private List<StudentNotificationView> buildNotifications(
            Student student,
            List<TimetableSlotView> todaySchedule,
            List<SubjectSummaryView> subjectSummaries,
            double pendingFees,
            DayScheduleInsight dayScheduleInsight) {

        List<StudentNotificationView> items = new ArrayList<>();

        if (dayScheduleInsight.currentSlot() != null) {
            items.add(new StudentNotificationView(
                    "Current class is live",
                    dayScheduleInsight.currentSlot().getSubject() + " is running from "
                            + dayScheduleInsight.currentSlot().getStartTime() + " to "
                            + dayScheduleInsight.currentSlot().getEndTime() + " in "
                            + dayScheduleInsight.currentSlot().getRoom() + ".",
                    "Current slot",
                    "success",
                    "/timetable",
                    "fa-solid fa-bolt"
            ));
        } else if (dayScheduleInsight.nextSlot() != null) {
            items.add(new StudentNotificationView(
                    "Next class is lined up",
                    dayScheduleInsight.nextSlot().getSubject() + " starts at "
                            + dayScheduleInsight.nextSlot().getStartTime() + " with "
                            + dayScheduleInsight.nextSlot().getTeacher() + ".",
                    "Timetable",
                    "info",
                    "/timetable",
                    "fa-regular fa-clock"
            ));
        }

        if (!todaySchedule.isEmpty()) {
            items.add(new StudentNotificationView(
                    "Today's timetable is ready",
                    "You have " + todaySchedule.size() + " class(es) today with "
                            + dayScheduleInsight.upcomingCount() + " upcoming slot(s) left.",
                    "Timetable",
                    "info",
                    "/timetable",
                    "fa-solid fa-calendar-days"
            ));
        } else {
            items.add(new StudentNotificationView(
                    "No classes scheduled today",
                    "Your timetable has no classes for today, so this is a free academic window.",
                    "Timetable",
                    "info",
                    "/timetable",
                    "fa-regular fa-calendar-xmark"
            ));
        }

        if (pendingFees > 0) {
            items.add(new StudentNotificationView(
                    "Fee balance pending",
                    "Your remaining fee amount is " + formatCurrency(pendingFees) + ".",
                    "Accounts",
                    "warning",
                    "/fees",
                    "fa-solid fa-indian-rupee-sign"
            ));
        } else {
            items.add(new StudentNotificationView(
                    "Fees are fully paid",
                    "No pending fee balance is left for your account.",
                    "Accounts",
                    "success",
                    "/fees",
                    "fa-solid fa-circle-check"
            ));
        }

        if (student.getClassRoom() != null) {
            items.add(new StudentNotificationView(
                    "Exam centre is linked",
                    "Exam and result updates for " + buildClassLabel(student) + " will appear in the exam section when published.",
                    "Exams",
                    "info",
                    "/exam-results",
                    "fa-solid fa-file-lines"
            ));
        } else {
            items.add(new StudentNotificationView(
                    "Classroom assignment pending",
                    "Your class context is still missing, so exam and schedule pages cannot be fully assigned yet.",
                    "Academic setup",
                    "warning",
                    "/student-profile",
                    "fa-solid fa-user-graduate"
            ));
        }

        if (!subjectSummaries.isEmpty()) {
            items.add(new StudentNotificationView(
                    "Subjects assigned successfully",
                    "Your dashboard is showing " + subjectSummaries.size() + " assigned subject(s) from the weekly timetable.",
                    "Subjects",
                    "success",
                    "/subjects",
                    "fa-solid fa-book-open"
            ));
        }

        return items;
    }

    private DayScheduleInsight buildDayScheduleInsight(List<TimetableSlotView> todaySchedule) {
        if (todaySchedule.isEmpty()) {
            return new DayScheduleInsight(0, 0, null, null);
        }

        LocalTime now = LocalTime.now();
        int completed = 0;
        int upcoming = 0;
        TimetableSlotView current = null;
        TimetableSlotView next = null;

        for (TimetableSlotView slot : todaySchedule) {
            LocalTime start = parseTime(slot.getStartTime());
            LocalTime end = parseTime(slot.getEndTime());

            if (current == null && isValidTime(start) && isValidTime(end) && !now.isBefore(start) && now.isBefore(end)) {
                current = slot;
                continue;
            }

            if (isValidTime(end) && now.compareTo(end) >= 0) {
                completed++;
                continue;
            }

            if (isValidTime(start) && now.isBefore(start)) {
                upcoming++;
                if (next == null) {
                    next = slot;
                }
            }
        }

        if (current != null) {
            upcoming = Math.max(upcoming, 0);
        }

        return new DayScheduleInsight(completed, upcoming, current, next);
    }

    private String resolveStudentId(Student student) {
        if (student.getRegistrationNo() != null && !student.getRegistrationNo().isBlank()) {
            return student.getRegistrationNo();
        }
        if (student.getEnrollmentNo() != null && !student.getEnrollmentNo().isBlank()) {
            return student.getEnrollmentNo();
        }
        if (student.getRollNo() != null && !student.getRollNo().isBlank()) {
            return student.getRollNo();
        }
        return student.getId() != null ? "STU-" + student.getId() : "Not assigned";
    }

    private String buildStudentInitials(String name) {
        if (name == null || name.isBlank()) return "ST";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.ENGLISH);
        }
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1))
                .toUpperCase(Locale.ENGLISH);
    }

    private String buildSemesterLabel(Student student) {
        String semester = defaultText(student.getSemester(), "");
        if (!semester.isBlank()) {
            return semester;
        }
        if (student.getClassRoom() != null && student.getClassRoom().getSemester() != null) {
            return "Sem " + student.getClassRoom().getSemester();
        }
        return "Not assigned";
    }

    private String buildSectionLabel(Student student) {
        if (student.getSectionName() != null && !student.getSectionName().isBlank()) {
            return "Section " + student.getSectionName();
        }
        if (student.getClassRoom() != null && student.getClassRoom().getSection() != null
                && !student.getClassRoom().getSection().isBlank()) {
            return "Section " + student.getClassRoom().getSection();
        }
        return "Section not assigned";
    }

    private String buildClassLabel(Student student) {
        ClassRoom classRoom = student.getClassRoom();
        if (classRoom != null) {
            String label = classRoom.getDisplayLabel();
            if (label != null && !label.isBlank()) {
                return label.replace("â€“", "-");
            }
        }

        List<String> parts = new ArrayList<>();
        if (student.getCourse() != null && !student.getCourse().isBlank()) parts.add(student.getCourse());
        String semester = buildSemesterLabel(student);
        if (!semester.equals("Not assigned")) parts.add(semester);
        String section = buildSectionLabel(student);
        if (!section.equals("Section not assigned")) parts.add(section);
        return parts.isEmpty() ? "Class not assigned" : String.join(" - ", parts);
    }

    private String resolveTeacherName(Teacher teacher) {
        return teacher != null ? defaultText(teacher.getName(), "Faculty not assigned") : "Faculty not assigned";
    }

    private String resolveClassMentor(Student student) {
        if (student.getClassRoom() != null && student.getClassRoom().getTeacher() != null) {
            return resolveTeacherName(student.getClassRoom().getTeacher());
        }
        return "Faculty not assigned";
    }

    private String resolvePrimaryRoom(Student student, TimetableSlotView currentSlot) {
        if (currentSlot != null && currentSlot.getRoom() != null && !currentSlot.getRoom().isBlank()) {
            return currentSlot.getRoom();
        }
        if (student.getClassRoom() != null && student.getClassRoom().getRoom() != null
                && !student.getClassRoom().getRoom().isBlank()) {
            return student.getClassRoom().getRoom();
        }
        return "Room not assigned";
    }

    private String normalizeDay(String day) {
        if (day == null || day.isBlank()) return "Monday";
        String clean = day.trim().toLowerCase(Locale.ENGLISH);
        return switch (clean) {
            case "mon", "monday" -> "Monday";
            case "tue", "tues", "tuesday" -> "Tuesday";
            case "wed", "wednesday" -> "Wednesday";
            case "thu", "thur", "thurs", "thursday" -> "Thursday";
            case "fri", "friday" -> "Friday";
            case "sat", "saturday" -> "Saturday";
            case "sun", "sunday" -> "Sunday";
            default -> Character.toUpperCase(clean.charAt(0)) + clean.substring(1);
        };
    }

    private int dayOrderIndex(String day) {
        int index = WORKING_DAYS.indexOf(normalizeDay(day));
        return index >= 0 ? index : WORKING_DAYS.size();
    }

    private LocalTime parseTime(String value) {
        if (value == null || value.isBlank()) return LocalTime.MAX;

        List<DateTimeFormatter> formatters = List.of(
                DateTimeFormatter.ofPattern("H:mm"),
                DateTimeFormatter.ofPattern("HH:mm"),
                DateTimeFormatter.ofPattern("h:mm a"),
                DateTimeFormatter.ofPattern("h:mm a", Locale.ENGLISH)
        );

        for (DateTimeFormatter formatter : formatters) {
            try {
                return LocalTime.parse(value.trim().toUpperCase(Locale.ENGLISH), formatter);
            } catch (Exception ignored) {
            }
        }
        return LocalTime.MAX;
    }

    private boolean isValidTime(LocalTime value) {
        return value != null && !LocalTime.MAX.equals(value);
    }

    private String currentDayName() {
        DayOfWeek current = LocalDate.now().getDayOfWeek();
        return current.getDisplayName(TextStyle.FULL, Locale.ENGLISH);
    }

    private double safeNumber(Double value) {
        return value != null ? value : 0.0;
    }

    private String formatCurrency(double amount) {
        return "₹" + CURRENCY_FORMAT.format(Math.round(amount));
    }

    private String formatDate(LocalDate date) {
        return date != null ? date.format(DATE_FORMAT) : "Not provided";
    }

    private String defaultText(String value, String fallback) {
        return (value == null || value.isBlank()) ? fallback : value.trim();
    }

    private String maskValue(String value, int visibleDigits) {
        if (value == null || value.isBlank()) return "Not provided";
        String trimmed = value.replaceAll("\\s+", "");
        if (trimmed.length() <= visibleDigits) return trimmed;
        String hidden = "X".repeat(Math.max(0, trimmed.length() - visibleDigits));
        return hidden + trimmed.substring(trimmed.length() - visibleDigits);
    }

    private String buildSubjectClass(String subject) {
        if (subject == null) return "free";
        String normalized = subject.toLowerCase(Locale.ENGLISH);
        if (normalized.contains("java")) return "java";
        if (normalized.contains("artificial") || normalized.contains("ai")) return "ai";
        if (normalized.contains("database")) return "db";
        if (normalized.contains("software")) return "se";
        if (normalized.contains("network")) return "cn";
        if (normalized.contains("lab") || normalized.contains("web")) return "lab";
        return "free";
    }

    private String shortDayName(String day) {
        return normalizeDay(day).substring(0, Math.min(3, normalizeDay(day).length()));
    }

    private record StudentPortalData(
            String studentId,
            String rollNo,
            String initials,
            String semesterLabel,
            String sectionLabel,
            String academicYear,
            String classLabel,
            String classMentor,
            String primaryRoom,
            String todayLabel,
            String todayDayKey,
            String todayFullDate,
            double totalFees,
            double paidFees,
            double pendingFees,
            String totalFeesFormatted,
            String paidFeesFormatted,
            String pendingFeesFormatted,
            int paidPercentage,
            int activeAcademicDays,
            int todayCompletedCount,
            int todayUpcomingCount,
            TimetableSlotView currentSlot,
            TimetableSlotView nextSlot,
            LinkedHashMap<String, List<TimetableSlotView>> weeklySchedule,
            List<WeeklyTimetableRowView> weeklyTimetableRows,
            List<TimetableSlotView> todaySchedule,
            List<Timetable> allTimetableEntries,
            List<SubjectSummaryView> subjectSummaries,
            List<StudentNotificationView> notifications
    ) {}

    private record DayScheduleInsight(
            int completedCount,
            int upcomingCount,
            TimetableSlotView currentSlot,
            TimetableSlotView nextSlot
    ) {}

    public static final class TimetableSlotView {
        private final String dayName;
        private final String startTime;
        private final String endTime;
        private final String subject;
        private final String teacher;
        private final String room;
        private final String subjectClass;

        public TimetableSlotView(String dayName, String startTime, String endTime,
                                 String subject, String teacher, String room, String subjectClass) {
            this.dayName = dayName;
            this.startTime = startTime;
            this.endTime = endTime;
            this.subject = subject;
            this.teacher = teacher;
            this.room = room;
            this.subjectClass = subjectClass;
        }

        public String getDayName() { return dayName; }
        public String getStartTime() { return startTime; }
        public String getEndTime() { return endTime; }
        public String getSubject() { return subject; }
        public String getTeacher() { return teacher; }
        public String getRoom() { return room; }
        public String getSubjectClass() { return subjectClass; }
        public String getTimeRange() { return startTime + " - " + endTime; }
    }

    public static final class SubjectSummaryView {
        private final String subjectName;
        private final String teacherName;
        private final String room;
        private final String daySummary;
        private final int classCount;
        private final String primaryTimeRange;
        private final List<String> scheduleMoments;
        private final String subjectClass;

        public SubjectSummaryView(String subjectName, String teacherName, String room, String daySummary,
                                  int classCount, String primaryTimeRange, List<String> scheduleMoments,
                                  String subjectClass) {
            this.subjectName = subjectName;
            this.teacherName = teacherName;
            this.room = room;
            this.daySummary = daySummary;
            this.classCount = classCount;
            this.primaryTimeRange = primaryTimeRange;
            this.scheduleMoments = scheduleMoments;
            this.subjectClass = subjectClass;
        }

        public String getSubjectName() { return subjectName; }
        public String getTeacherName() { return teacherName; }
        public String getRoom() { return room; }
        public String getDaySummary() { return daySummary; }
        public int getClassCount() { return classCount; }
        public String getPrimaryTimeRange() { return primaryTimeRange; }
        public List<String> getScheduleMoments() { return scheduleMoments; }
        public String getSubjectClass() { return subjectClass; }
    }

    public static final class WeeklyTimetableRowView {
        private final String startTime;
        private final String endTime;
        private final String timeLabel;
        private final Map<String, TimetableSlotView> slotsByDay;

        public WeeklyTimetableRowView(String startTime, String endTime, String timeLabel, Map<String, TimetableSlotView> slotsByDay) {
            this.startTime = startTime;
            this.endTime = endTime;
            this.timeLabel = timeLabel;
            this.slotsByDay = slotsByDay;
        }

        public String getStartTime() { return startTime; }
        public String getEndTime() { return endTime; }
        public String getTimeLabel() { return timeLabel; }
        public Map<String, TimetableSlotView> getSlotsByDay() { return slotsByDay; }
        public TimetableSlotView getSlotForDay(String day) { return slotsByDay.get(day); }
    }

    public static final class StudentNotificationView {
        private final String title;
        private final String description;
        private final String source;
        private final String tone;
        private final String targetUrl;
        private final String iconClass;

        public StudentNotificationView(String title, String description, String source, String tone,
                                       String targetUrl, String iconClass) {
            this.title = title;
            this.description = description;
            this.source = source;
            this.tone = tone;
            this.targetUrl = targetUrl;
            this.iconClass = iconClass;
        }

        public String getTitle() { return title; }
        public String getDescription() { return description; }
        public String getSource() { return source; }
        public String getTone() { return tone; }
        public String getTargetUrl() { return targetUrl; }
        public String getIconClass() { return iconClass; }
    }

    private static final class SubjectSummaryViewBuilder {
        private final String subjectName;
        private final String teacherName;
        private final String subjectClass;
        private String room = "Room not assigned";
        private final LinkedHashSet<String> days = new LinkedHashSet<>();
        private final List<String> scheduleMoments = new ArrayList<>();
        private String primaryTimeRange = "--";
        private int classCount = 0;

        private SubjectSummaryViewBuilder(String subjectName, String teacherName, String subjectClass) {
            this.subjectName = subjectName;
            this.teacherName = teacherName;
            this.subjectClass = subjectClass;
        }

        private void addEntry(String day, String startTime, String endTime) {
            days.add(day);
            scheduleMoments.add(shortLabel(day, startTime, endTime));
            classCount++;
            if ("--".equals(primaryTimeRange)) {
                primaryTimeRange = startTime + " - " + endTime;
            }
        }

        private void setRoom(String room) {
            this.room = room;
        }

        private SubjectSummaryView build() {
            return new SubjectSummaryView(
                    subjectName,
                    teacherName,
                    room,
                    String.join(", ", days),
                    classCount,
                    primaryTimeRange,
                    List.copyOf(scheduleMoments),
                    subjectClass
            );
        }

        private String shortLabel(String day, String startTime, String endTime) {
            return day.substring(0, Math.min(3, day.length())) + " " + startTime + " - " + endTime;
        }
    }

    private static final class WeeklyTimetableRowBuilder {
        private final String startTime;
        private final String endTime;
        private final LinkedHashMap<String, TimetableSlotView> slotsByDay = new LinkedHashMap<>();

        private WeeklyTimetableRowBuilder(String startTime, String endTime) {
            this.startTime = startTime;
            this.endTime = endTime;
        }

        private void put(String day, TimetableSlotView slot) {
            slotsByDay.put(day, slot);
        }

        private String startTime() {
            return startTime;
        }

        private WeeklyTimetableRowView build() {
            LinkedHashMap<String, TimetableSlotView> orderedSlots = new LinkedHashMap<>();
            for (String day : WORKING_DAYS) {
                orderedSlots.put(day, slotsByDay.get(day));
            }
            return new WeeklyTimetableRowView(
                    startTime,
                    endTime,
                    startTime + " - " + endTime,
                    orderedSlots
            );
        }
    }
}
