package com.scms.scms.model;

import jakarta.persistence.*;
import com.scms.scms.security.SensitiveStringConverter;
import java.time.LocalDate;

@Entity
@Table(name = "student")
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ── Core Login ──
    private String name;
    private String email;
    private String password;

    // ── Academic ──
    private String course;
    private String semester;
    private String academicYear;
    private String degree;       // UG / PG / Diploma
    private String sectionName;  // A, B, C
    private String medium;       // English / Hindi / Marathi

    // ── Identification Numbers ──
    private String rollNo;
    private String enrollmentNo;
    private String registrationNo;
    private String prnNumber;
    private String abcNumber;

    // ── Personal Info ──
    private String gender;
    private LocalDate dob;
    private String bloodGroup;
    private String religion;
    private LocalDate admissionDate;
    private String casteName;
    private String category;

    // ── Family Info ──
    private String fatherName;
    private String motherName;
    private String guardianName;

    // ── Government IDs ──
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String aadharNumber;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String panCardNumber;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String voterId;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String eidNumber;

    // ── Bank Details ──
    private String bankName;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String bankAccNo;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String ifscCode;
    @Column(length = 512)
    @Convert(converter = SensitiveStringConverter.class)
    private String micrNumber;

    // ── Photo (web path stored, not the file itself) ──
    private String photo;

    // ── Fees ──
    private Double totalFees;
    private Double paidFees;
    private Double pendingFees;

    // ── Relations ──
    @ManyToOne
    @JoinColumn(name = "class_id")
    private ClassRoom classRoom;

    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Admin admin;

    // ════════════════════════════════
    //  Constructors
    // ════════════════════════════════
    public Student() {}

    // ════════════════════════════════
    //  Getters & Setters
    // ════════════════════════════════

    public Long getId() { return id; }

    // Core Login
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }

    // Academic
    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getSemester() { return semester; }
    public void setSemester(String semester) { this.semester = semester; }

    public String getAcademicYear() { return academicYear; }
    public void setAcademicYear(String academicYear) { this.academicYear = academicYear; }

    public String getDegree() { return degree; }
    public void setDegree(String degree) { this.degree = degree; }

    public String getSectionName() { return sectionName; }
    public void setSectionName(String sectionName) { this.sectionName = sectionName; }

    public String getMedium() { return medium; }
    public void setMedium(String medium) { this.medium = medium; }

    // Identification Numbers
    public String getRollNo() { return rollNo; }
    public void setRollNo(String rollNo) { this.rollNo = rollNo; }

    public String getEnrollmentNo() { return enrollmentNo; }
    public void setEnrollmentNo(String enrollmentNo) { this.enrollmentNo = enrollmentNo; }

    public String getRegistrationNo() { return registrationNo; }
    public void setRegistrationNo(String registrationNo) { this.registrationNo = registrationNo; }

    public String getPrnNumber() { return prnNumber; }
    public void setPrnNumber(String prnNumber) { this.prnNumber = prnNumber; }

    public String getAbcNumber() { return abcNumber; }
    public void setAbcNumber(String abcNumber) { this.abcNumber = abcNumber; }

    // Personal Info
    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public LocalDate getDob() { return dob; }
    public void setDob(LocalDate dob) { this.dob = dob; }

    public String getBloodGroup() { return bloodGroup; }
    public void setBloodGroup(String bloodGroup) { this.bloodGroup = bloodGroup; }

    public String getReligion() { return religion; }
    public void setReligion(String religion) { this.religion = religion; }

    public LocalDate getAdmissionDate() { return admissionDate; }
    public void setAdmissionDate(LocalDate admissionDate) { this.admissionDate = admissionDate; }

    public String getCasteName() { return casteName; }
    public void setCasteName(String casteName) { this.casteName = casteName; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    // Family Info
    public String getFatherName() { return fatherName; }
    public void setFatherName(String fatherName) { this.fatherName = fatherName; }

    public String getMotherName() { return motherName; }
    public void setMotherName(String motherName) { this.motherName = motherName; }

    public String getGuardianName() { return guardianName; }
    public void setGuardianName(String guardianName) { this.guardianName = guardianName; }

    // Government IDs
    public String getAadharNumber() { return aadharNumber; }
    public void setAadharNumber(String aadharNumber) { this.aadharNumber = aadharNumber; }

    public String getPanCardNumber() { return panCardNumber; }
    public void setPanCardNumber(String panCardNumber) { this.panCardNumber = panCardNumber; }

    public String getVoterId() { return voterId; }
    public void setVoterId(String voterId) { this.voterId = voterId; }

    public String getEidNumber() { return eidNumber; }
    public void setEidNumber(String eidNumber) { this.eidNumber = eidNumber; }

    // Bank Details
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }

    public String getBankAccNo() { return bankAccNo; }
    public void setBankAccNo(String bankAccNo) { this.bankAccNo = bankAccNo; }

    public String getIfscCode() { return ifscCode; }
    public void setIfscCode(String ifscCode) { this.ifscCode = ifscCode; }

    public String getMicrNumber() { return micrNumber; }
    public void setMicrNumber(String micrNumber) { this.micrNumber = micrNumber; }

    // Photo
    public String getPhoto() { return photo; }
    public void setPhoto(String photo) { this.photo = photo; }

    // Fees
    public Double getTotalFees() { return totalFees; }
    public void setTotalFees(Double totalFees) { this.totalFees = totalFees; }

    public Double getPaidFees() { return paidFees; }
    public void setPaidFees(Double paidFees) { this.paidFees = paidFees; }

    public Double getPendingFees() { return pendingFees; }
    public void setPendingFees(Double pendingFees) { this.pendingFees = pendingFees; }

    // Relations
    public ClassRoom getClassRoom() { return classRoom; }
    public void setClassRoom(ClassRoom classRoom) { this.classRoom = classRoom; }

    public Admin getAdmin() { return admin; }
    public void setAdmin(Admin admin) { this.admin = admin; }
}
