package com.scms.scms.model;

import jakarta.persistence.*;

@Entity
@Table(name = "fees")  // ← matches your DB table name exactly
public class Fees {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "course")
    private String course;          // "MCA", "BCA", "BSc"

    @Column(name = "total_amount")
    private double totalAmount;     // 80000, 60000, 50000

    // ── Getters & Setters ──

    public Long getId() { return id; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
}