package com.scms.scms.controller;

import com.scms.scms.model.Admin;
import com.scms.scms.model.ClassRoom;
import com.scms.scms.model.Student;
import com.scms.scms.model.Teacher;
import com.scms.scms.model.StudyMaterial;
import com.scms.scms.repository.StudentRepository;
import com.scms.scms.repository.StudyMaterialRepository;
import com.scms.scms.repository.TeacherRepository;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@Controller
public class TeacherController {

    @Autowired private StudentRepository studentRepository;
    @Autowired private TeacherRepository teacherRepository;
    @Autowired private StudyMaterialRepository studyMaterialRepository;

    @GetMapping("/teacher-dashboard")
    public String dashboard(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        List<Student> students = loadVisibleStudents(teacher);
        model.addAttribute("totalStudents", students.size());
        model.addAttribute("students", students);
        addStudyMaterialAttributes(model, teacher);
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-dashboard";
    }

    @GetMapping("/teacher-students")
    public String students(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        List<Student> students = loadVisibleStudents(teacher);
        model.addAttribute("students", students);
        model.addAttribute("totalStudents", students.size());
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-students";
    }

    @GetMapping("/teacher-attendance")
    public String attendance(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        model.addAttribute("students", loadVisibleStudents(teacher));
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-attendance";
    }

    @PostMapping("/teacher-attendance-submit")
    public String submitAttendance(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        model.addAttribute("success", "Attendance saved!");
        model.addAttribute("students", loadVisibleStudents(teacher));
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-attendance";
    }

    @GetMapping("/teacher-marks")
    public String marks(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        model.addAttribute("students", loadVisibleStudents(teacher));
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-marks";
    }

    @PostMapping("/teacher-marks-submit")
    public String submitMarks(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";

        model.addAttribute("success", "Marks saved!");
        model.addAttribute("students", loadVisibleStudents(teacher));
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-marks";
    }

    @GetMapping("/teacher-assignments")
    public String assignments(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-assignments";
    }

    @PostMapping("/teacher-assignment-add")
    public String addAssign(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";
        model.addAttribute("success", "Assignment created!");
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-assignments";
    }

    @GetMapping("/teacher-timetable")
    public String timetable(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-timetable";
    }

    @GetMapping("/teacher-profile")
    public String profile(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-profile";
    }

    @GetMapping("/teacher-notifications")
    public String notifications(Model model, HttpSession session) {
        Teacher teacher = getLoggedTeacher(session);
        if (teacher == null) return "redirect:/login";
        addTeacherAttributes(model, teacher);
        return "teacher/teacher-notifications";
    }

    private Teacher getLoggedTeacher(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        String role = (String) session.getAttribute("userRole");
        if (email == null || (role != null && !"TEACHER".equalsIgnoreCase(role))) {
            return null;
        }
        return teacherRepository.findByEmail(email);
    }

    private List<Student> loadVisibleStudents(Teacher teacher) {
        ClassRoom classRoom = teacher.getClassRoom();
        Admin admin = teacher.getAdmin();

        if (admin != null && classRoom != null) {
            return studentRepository.findByAdminAndClassRoom(admin, classRoom);
        }
        if (classRoom != null) {
            return studentRepository.findByClassRoom(classRoom);
        }
        if (admin != null) {
            return studentRepository.findByAdmin(admin);
        }
        return List.of();
    }

    private void addTeacherAttributes(Model model, Teacher teacher) {
        model.addAttribute("teacher", teacher);
        model.addAttribute("teacherName", teacher.getName());
        model.addAttribute("teacherEmail", teacher.getEmail());
        model.addAttribute("teacherSubject", teacher.getSubject());
    }

    private void addStudyMaterialAttributes(Model model, Teacher teacher) {
        List<StudyMaterial> materials = loadTeacherMaterials(teacher);
        model.addAttribute("teacherStudyMaterials", materials);
        model.addAttribute("teacherStudyMaterialsBySubject", materials.stream()
                .collect(Collectors.groupingBy(
                        material -> material.getSubject() != null && !material.getSubject().isBlank()
                                ? material.getSubject()
                                : "Unassigned",
                        java.util.LinkedHashMap::new,
                        Collectors.toList()
                )));
        model.addAttribute("teacherStudyMaterialCount", materials.size());
        model.addAttribute("teacherStudyMaterialSubjectCount", materials.stream()
                .map(material -> material.getSubject() != null && !material.getSubject().isBlank()
                        ? material.getSubject()
                        : "Unassigned")
                .distinct()
                .count());
        model.addAttribute("teacherStudyMaterialStudents", materials.stream()
                .map(material -> material.getClassRoom() != null ? material.getClassRoom().getDisplayLabel() : "Unassigned class")
                .distinct()
                .count());
        model.addAttribute("teacherDefaultSubject", teacher.getSubject() != null && !teacher.getSubject().isBlank()
                ? teacher.getSubject()
                : "General");
        model.addAttribute("teacherDefaultSemester", teacher.getClassRoom() != null && teacher.getClassRoom().getSemester() != null
                ? String.valueOf(teacher.getClassRoom().getSemester())
                : "");
        model.addAttribute("teacherClassLabel", teacher.getClassRoom() != null ? teacher.getClassRoom().getDisplayLabel() : "No class assigned");
    }

    private List<StudyMaterial> loadTeacherMaterials(Teacher teacher) {
        ClassRoom classRoom = teacher.getClassRoom();
        List<StudyMaterial> materials = classRoom != null
                ? studyMaterialRepository.findByClassRoomOrderByUploadedAtDesc(classRoom)
                : studyMaterialRepository.findAllByOrderByUploadedAtDesc();

        if (materials.isEmpty() && teacher.getAdmin() != null) {
            materials = studyMaterialRepository.findByAdminOrderByUploadedAtDesc(teacher.getAdmin());
        }

        Long teacherId = teacher.getId();
        Long classId = classRoom != null ? classRoom.getId() : null;
        Long adminId = teacher.getAdmin() != null ? teacher.getAdmin().getId() : null;

        return materials.stream()
                .filter(material -> (material.getTeacher() != null && teacherId != null && teacherId.equals(material.getTeacher().getId()))
                        || (classId != null && material.getClassRoom() != null && classId.equals(material.getClassRoom().getId()))
                        || (adminId != null && material.getAdmin() != null && adminId.equals(material.getAdmin().getId()))
                        || (material.getTeacher() == null && material.getClassRoom() == null && material.getAdmin() == null))
                .toList();
    }
}
