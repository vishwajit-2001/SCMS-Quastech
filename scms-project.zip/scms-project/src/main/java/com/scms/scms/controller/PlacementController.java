package com.scms.scms.controller;

import com.scms.scms.model.*;
import com.scms.scms.repository.*;
import com.scms.scms.service.PasswordProtectionService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Controller
public class PlacementController {

    private static final String UPLOAD_DIR_RESUMES =
            System.getProperty("user.dir") + "/src/main/resources/static/uploads/placements/resumes/";

    @Autowired private PlacementTpoRepository placementTpoRepository;
    @Autowired private PlacementDriveRepository placementDriveRepository;
    @Autowired private PlacementApplicationRepository placementApplicationRepository;
    @Autowired private StudentRepository studentRepository;
    @Autowired private PasswordProtectionService passwordProtectionService;

    @GetMapping("/login-placement")
    public String loginPage() {
        return "placement/login-placement";
    }

    @PostMapping("/placement-login")
    public String login(
            @RequestParam String email,
            @RequestParam String password,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        String cleanEmail = email == null ? "" : email.trim();
        String cleanPassword = password == null ? "" : password.trim();

        if (cleanEmail.isBlank() || cleanPassword.isBlank()) {
            redirectAttributes.addFlashAttribute("errorLogin", "Email and password are required!");
            return "redirect:/login-placement";
        }

        PlacementTpo tpo = placementTpoRepository.findByEmail(cleanEmail);
        if (tpo != null && passwordProtectionService.matches(cleanPassword, tpo.getPassword())) {
            upgradeLegacyPasswordIfNeeded(tpo, cleanPassword);
            session.setAttribute("loggedInUser", tpo.getEmail());
            session.setAttribute("userRole", "PLACEMENT_TPO");
            return "redirect:/placement-dashboard";
        }

        redirectAttributes.addFlashAttribute("errorLogin", "Invalid email or password!");
        return "redirect:/login-placement";
    }

    @GetMapping("/placement-logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @GetMapping("/placement-dashboard")
    public String dashboard(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-dashboard";
    }

    @GetMapping("/placement-company-drives")
    public String companyDrives(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-company-drives";
    }

    @GetMapping("/placement-applications")
    public String applications(Model model, HttpSession session, @RequestParam(required = false) String company) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        model.addAttribute("applicationCompanyFilter", company == null ? "" : company.trim());
        model.addAttribute("filteredPlacementApplications", filterApplicationsByCompany((String) model.getAttribute("applicationCompanyFilter")));
        return "placement/placement-applications";
    }

    @GetMapping("/placement-students")
    public String students(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-students";
    }

    @GetMapping("/placement-companies")
    public String companies(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-companies";
    }

    @GetMapping("/placement-interviews")
    public String interviews(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-interviews";
    }

    @GetMapping("/placement-analytics")
    public String analytics(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-analytics";
    }

    @GetMapping("/placement-reports")
    public String reports(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-reports";
    }

    @GetMapping("/placement-announcements")
    public String announcements(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-announcements";
    }

    @GetMapping("/placement-settings")
    public String settings(Model model, HttpSession session) {
        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";
        addWorkspaceModel(model, tpo);
        return "placement/placement-settings";
    }

    @GetMapping("/placements")
    public String studentPlacements(Model model, HttpSession session) {
        Student student = getLoggedStudent(session);
        if (student == null) return "redirect:/login";

        List<PlacementDrive> drives = placementDriveRepository.findByPublishedTrueOrderByCreatedAtDesc().stream()
                .filter(drive -> driveVisibleToStudent(drive, student))
                .toList();

        List<Long> appliedDriveIds = placementApplicationRepository.findByStudentOrderByAppliedAtDesc(student).stream()
                .map(app -> app.getPlacementDrive().getId())
                .toList();

        model.addAttribute("student", student);
        model.addAttribute("studentName", safe(student.getName(), "Student"));
        model.addAttribute("studentCourse", safe(student.getCourse(), "Not assigned"));
        model.addAttribute("studentSemesterLabel", safe(student.getSemester(), "Not assigned"));
        model.addAttribute("studentEmail", safe(student.getEmail(), "Not available"));
        model.addAttribute("studentInitials", buildInitials(student.getName()));
        model.addAttribute("notificationCount", 0);
        model.addAttribute("placementDrives", drives);
        model.addAttribute("placementDriveCount", drives.size());
        model.addAttribute("placementAppliedDriveIds", appliedDriveIds);
        model.addAttribute("placementOpenDriveIds", drives.stream()
                .filter(PlacementDrive::isApplicationOpen)
                .map(PlacementDrive::getId)
                .toList());
        model.addAttribute("placementEmptyMessage", "No placement drives are live for your profile yet.");
        return "student/connected/placements-v2";
    }

    @PostMapping("/placement-drives")
    public String createDrive(
            @RequestParam String companyName,
            @RequestParam String jobTitle,
            @RequestParam(required = false) String packageOffered,
            @RequestParam String location,
            @RequestParam(required = false) String driveType,
            @RequestParam(required = false) String eligibilityCourse,
            @RequestParam(required = false) String eligibilitySemester,
            @RequestParam(required = false) String eligibilityDegree,
            @RequestParam(required = false) String experience,
            @RequestParam(required = false) String salaryRange,
            @RequestParam(required = false) String skillsRequired,
            @RequestParam(required = false) String description,
            @RequestParam(required = false) String driveDate,
            @RequestParam(required = false) String applicationDeadlineDate,
            @RequestParam(required = false) String applicationDeadlineTime,
            @RequestParam(required = false) Integer openings,
            @RequestParam(defaultValue = "true") boolean published,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        PlacementTpo tpo = getLoggedTpo(session);
        if (tpo == null) return "redirect:/login-placement";

        PlacementDrive drive = new PlacementDrive();
        drive.setCompanyName(safe(companyName, "Company"));
        drive.setJobTitle(safe(jobTitle, "Hiring"));
        drive.setPackageOffered(safe(packageOffered, "Not disclosed"));
        drive.setLocation(safe(location, "On campus"));
        drive.setDriveType(safe(driveType, "On Campus"));
        drive.setExperience(normalizeBlank(experience));
        drive.setSalaryRange(normalizeBlank(salaryRange != null ? salaryRange : packageOffered));
        drive.setEligibilityCourse(normalizeBlank(eligibilityCourse));
        drive.setEligibilitySemester(normalizeBlank(eligibilitySemester));
        drive.setEligibilityDegree(normalizeBlank(eligibilityDegree));
        drive.setSkillsRequired(normalizeBlank(skillsRequired));
        drive.setDescription(normalizeBlank(description));
        drive.setOpenings(openings != null ? openings : 1);
        drive.setDriveDate(parseDate(driveDate));
        drive.setApplicationDeadline(parseDeadline(applicationDeadlineDate, applicationDeadlineTime));
        drive.setPublished(published);
        drive.setCreatedAt(LocalDateTime.now());
        drive.setPlacementTpo(tpo);
        placementDriveRepository.save(drive);

        redirectAttributes.addFlashAttribute("placementSuccess", "Placement drive published successfully.");
        return "redirect:/placement-company-drives";
    }

    @PostMapping("/placements/apply/{driveId}")
    public String apply(
            @PathVariable Long driveId,
            @RequestParam String fullName,
            @RequestParam String phone,
            @RequestParam String email,
            @RequestParam String course,
            @RequestParam String semester,
            @RequestParam(required = false) String specialization,
            @RequestParam(required = false) String currentLocation,
            @RequestParam(required = false) String skills,
            @RequestParam(required = false) String coverNote,
            @RequestParam(value = "resume", required = false) MultipartFile resumeFile,
            HttpSession session,
            RedirectAttributes redirectAttributes) {

        Student student = getLoggedStudent(session);
        if (student == null) return "redirect:/login";

        PlacementDrive drive = placementDriveRepository.findById(driveId).orElse(null);
        if (drive == null || !drive.isPublished() || !driveVisibleToStudent(drive, student)) {
            redirectAttributes.addFlashAttribute("placementError", "This drive is not available for your profile.");
            return "redirect:/placements";
        }

        if (!drive.isApplicationOpen()) {
            redirectAttributes.addFlashAttribute("placementError", "Application deadline has closed for this drive.");
            return "redirect:/placements";
        }

        if (placementApplicationRepository.existsByPlacementDriveAndEmail(drive, email.trim())) {
            redirectAttributes.addFlashAttribute("placementError", "You have already applied for this company.");
            return "redirect:/placements";
        }

        String resumePath = saveResume(resumeFile);
        if (resumeFile != null && !resumeFile.isEmpty() && resumePath == null) {
            redirectAttributes.addFlashAttribute("placementError", "Resume upload failed. Use PDF/DOC/DOCX under 10 MB.");
            return "redirect:/placements";
        }

        PlacementApplication application = new PlacementApplication();
        application.setPlacementDrive(drive);
        application.setStudent(student);
        application.setFullName(safe(fullName, student.getName()));
        application.setPhone(normalizeBlank(phone));
        application.setEmail(normalizeBlank(email));
        application.setCourse(normalizeBlank(course));
        application.setSemester(normalizeBlank(semester));
        application.setSpecialization(normalizeBlank(specialization));
        application.setCurrentLocation(normalizeBlank(currentLocation));
        application.setSkills(normalizeBlank(skills));
        application.setCoverNote(normalizeBlank(coverNote));
        application.setResumePath(resumePath);
        application.setResumeName(resumeFile != null ? normalizeBlank(resumeFile.getOriginalFilename()) : null);
        application.setStatus("Submitted");
        application.setAppliedAt(LocalDateTime.now());
        placementApplicationRepository.save(application);

        redirectAttributes.addFlashAttribute("placementSuccess", "Your application has been sent to the placement TPO.");
        return "redirect:/placements";
    }

    private void addWorkspaceModel(Model model, PlacementTpo tpo) {
        List<PlacementDrive> drives = placementDriveRepository.findByPlacementTpoOrderByCreatedAtDesc(tpo);
        List<PlacementApplication> applications = collectApplications(drives);
        List<Student> students = resolveStudentsForDashboard(tpo);
        List<String> companies = drives.stream()
                .map(PlacementDrive::getCompanyName)
                .filter(value -> value != null && !value.isBlank())
                .distinct()
                .sorted(String.CASE_INSENSITIVE_ORDER)
                .toList();

        model.addAttribute("placementTpo", tpo);
        model.addAttribute("placementTpoName", tpo.getName());
        model.addAttribute("placementTpoEmail", tpo.getEmail());
        model.addAttribute("placementTpoCollege", tpo.getCollegeName());
        model.addAttribute("placementTpoInitials", buildInitials(tpo.getName()));
        model.addAttribute("placementDriveCount", drives.size());
        model.addAttribute("placementApplicationCount", applications.size());
        model.addAttribute("placementPublishedCount", drives.stream().filter(PlacementDrive::isPublished).count());
        model.addAttribute("placementStudentCount", students.size());
        model.addAttribute("placementPlacedCount", applications.size());
        model.addAttribute("placementCompanyCount", companies.size());
        model.addAttribute("placementDrives", drives);
        model.addAttribute("placementApplications", applications);
        model.addAttribute("placementStudents", students);
        model.addAttribute("placementCompanies", companies);
        model.addAttribute("recentPlacementApplications", applications.stream().limit(8).toList());
        model.addAttribute("placementDriveOpenCount", drives.stream().filter(PlacementDrive::isApplicationOpen).count());
        model.addAttribute("placementDriveClosedCount", drives.stream().filter(drive -> !drive.isApplicationOpen()).count());
    }

    private List<PlacementApplication> collectApplications(List<PlacementDrive> drives) {
        List<PlacementApplication> applications = new ArrayList<>();
        for (PlacementDrive drive : drives) {
            applications.addAll(placementApplicationRepository.findByPlacementDriveOrderByAppliedAtDesc(drive));
        }
        return applications;
    }

    private List<PlacementApplication> filterApplicationsByCompany(String company) {
        String normalized = normalize(company);
        if (normalized.isBlank()) {
            return placementApplicationRepository.findAll().stream()
                    .sorted((a, b) -> {
                        LocalDateTime left = a.getAppliedAt();
                        LocalDateTime right = b.getAppliedAt();
                        if (left == null && right == null) return 0;
                        if (left == null) return 1;
                        if (right == null) return -1;
                        return right.compareTo(left);
                    })
                    .toList();
        }
        return placementApplicationRepository.findAll().stream()
                .filter(application -> application.getPlacementDrive() != null
                        && normalize(application.getPlacementDrive().getCompanyName()).contains(normalized))
                .sorted((a, b) -> {
                    LocalDateTime left = a.getAppliedAt();
                    LocalDateTime right = b.getAppliedAt();
                    if (left == null && right == null) return 0;
                    if (left == null) return 1;
                    if (right == null) return -1;
                    return right.compareTo(left);
                })
                .toList();
    }

    private PlacementTpo getLoggedTpo(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        String role = (String) session.getAttribute("userRole");
        if (email == null || (role != null && !"PLACEMENT_TPO".equalsIgnoreCase(role))) {
            return null;
        }
        return placementTpoRepository.findByEmail(email);
    }

    private Student getLoggedStudent(HttpSession session) {
        String email = (String) session.getAttribute("loggedInUser");
        String role = (String) session.getAttribute("userRole");
        if (email == null || (role != null && !"STUDENT".equalsIgnoreCase(role))) {
            return null;
        }
        return studentRepository.findByEmail(email);
    }

    private boolean driveVisibleToStudent(PlacementDrive drive, Student student) {
        String studentCourse = normalize(student.getCourse());
        String studentSemester = normalize(student.getSemester());
        String eligibleCourse = normalize(drive.getEligibilityCourse());
        String eligibleSemester = normalize(drive.getEligibilitySemester());
        String eligibleDegree = normalize(drive.getEligibilityDegree());

        boolean courseOk = eligibleCourse.isBlank() || studentCourse.contains(eligibleCourse) || eligibleCourse.contains(studentCourse);
        boolean semesterOk = eligibleSemester.isBlank() || studentSemester.equals(eligibleSemester) || studentSemester.contains(eligibleSemester);
        boolean degreeOk = eligibleDegree.isBlank() || normalize(student.getDegree()).contains(eligibleDegree) || eligibleDegree.contains(normalize(student.getDegree()));
        return courseOk && semesterOk && degreeOk;
    }

    private LocalDate parseDate(String value) {
        if (value == null || value.isBlank()) return null;
        try {
            return LocalDate.parse(value.trim());
        } catch (Exception ignored) {
            return null;
        }
    }

    private String safe(String value, String fallback) {
        return value == null || value.isBlank() ? fallback : value.trim();
    }

    private String normalizeBlank(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }

    private String normalize(String value) {
        return value == null ? "" : value.trim().toLowerCase(Locale.ENGLISH);
    }

    private LocalDateTime parseDeadline(String dateValue, String timeValue) {
        if (dateValue == null || dateValue.isBlank()) return null;
        try {
            LocalDate date = LocalDate.parse(dateValue.trim());
            LocalTime time = (timeValue == null || timeValue.isBlank()) ? LocalTime.of(23, 59) : LocalTime.parse(timeValue.trim());
            return LocalDateTime.of(date, time);
        } catch (Exception ignored) {
            return null;
        }
    }

    private String saveResume(MultipartFile file) {
        if (file == null || file.isEmpty()) return null;

        String name = file.getOriginalFilename() != null ? file.getOriginalFilename().toLowerCase(Locale.ENGLISH) : "";
        boolean allowed = name.endsWith(".pdf") || name.endsWith(".doc") || name.endsWith(".docx");
        if (!allowed || file.getSize() > 10L * 1024 * 1024) {
            return null;
        }

        File dir = new File(UPLOAD_DIR_RESUMES);
        if (!dir.exists() && !dir.mkdirs()) return null;

        String original = file.getOriginalFilename() != null ? file.getOriginalFilename() : "resume.pdf";
        String ext = original.contains(".") ? original.substring(original.lastIndexOf(".")) : ".pdf";
        String stored = UUID.randomUUID() + ext;
        try {
            Files.copy(file.getInputStream(), Paths.get(UPLOAD_DIR_RESUMES + stored), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            return "/uploads/placements/resumes/" + stored;
        } catch (IOException e) {
            return null;
        }
    }

    private List<Student> resolveStudentsForDashboard(PlacementTpo tpo) {
        if (tpo == null) return List.of();
        List<Student> students = new ArrayList<>();
        students.addAll(studentRepository.findAll().stream()
                .filter(student -> student.getAdmin() != null || student.getClassRoom() != null)
                .toList());
        return students;
    }

    private String buildInitials(String name) {
        if (name == null || name.isBlank()) return "ST";
        String[] parts = name.trim().split("\\s+");
        if (parts.length == 1) {
            return parts[0].substring(0, Math.min(2, parts[0].length())).toUpperCase(Locale.ENGLISH);
        }
        return (parts[0].substring(0, 1) + parts[parts.length - 1].substring(0, 1)).toUpperCase(Locale.ENGLISH);
    }

    private void upgradeLegacyPasswordIfNeeded(PlacementTpo tpo, String rawPassword) {
        if (passwordProtectionService.needsUpgrade(tpo.getPassword())) {
            tpo.setPassword(passwordProtectionService.encode(rawPassword));
            placementTpoRepository.save(tpo);
        }
    }
}
