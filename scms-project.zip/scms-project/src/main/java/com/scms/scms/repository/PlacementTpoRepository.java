package com.scms.scms.repository;

import com.scms.scms.model.PlacementTpo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PlacementTpoRepository extends JpaRepository<PlacementTpo, Long> {
    PlacementTpo findByEmail(String email);
    PlacementTpo findByEmailAndPassword(String email, String password);
}
