package com.scms.scms.repository;

import com.scms.scms.model.*;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface StudentRepository extends JpaRepository<Student, Long> {
    Student findByEmail(String email);
    List<Student> findByAdmin(Admin admin);
    List<Student> findByClassRoom(ClassRoom classRoom);
    List<Student> findByAdminAndClassRoom(Admin admin, ClassRoom classRoom);
}
