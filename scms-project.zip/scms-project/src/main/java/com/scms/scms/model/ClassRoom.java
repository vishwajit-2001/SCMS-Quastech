package com.scms.scms.model;

import jakarta.persistence.*;

@Entity
@Table(name = "classroom")
public class ClassRoom {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // e.g. "MCA-FY-Sem1", "BCA-SY-Sem3"
    private String name;

    // e.g. "MCA", "BCA", "BSc CS", "MSc CS"
    private String course;

    // e.g. "FY", "SY", "TY"
    private String year;

    // e.g. 1, 2, 3, 4, 5, 6
    private Integer semester;

    // e.g. "A", "B"
    private String section;

    // e.g. "101", "Lab A"
    private String room;

    // e.g. "FYMCA", "SYMCA"
    private String batch;

    // Class Teacher assigned to this classroom
    @ManyToOne
    @JoinColumn(name = "teacher_id")
    private Teacher teacher;

    // Which admin owns this classroom
    @ManyToOne
    @JoinColumn(name = "admin_id")
    private Admin admin;

    // ── Helpers ──

    /**
     * Returns a display label like "MCA – FY – Sem 1 (Section A)"
     */
    public String getDisplayLabel() {
        StringBuilder sb = new StringBuilder();
        if (course  != null) sb.append(course);
        if (year    != null) sb.append(" – ").append(year);
        if (semester!= null) sb.append(" – Sem ").append(semester);
        if (section != null && !section.isBlank()) sb.append(" (Sec ").append(section).append(")");
        return sb.toString();
    }

    // ════════════════════════════════
    // Getters & Setters
    // ════════════════════════════════

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getCourse() { return course; }
    public void setCourse(String course) { this.course = course; }

    public String getYear() { return year; }
    public void setYear(String year) { this.year = year; }

    public Integer getSemester() { return semester; }
    public void setSemester(Integer semester) { this.semester = semester; }

    public String getSection() { return section; }
    public void setSection(String section) { this.section = section; }

    public String getRoom() { return room; }
    public void setRoom(String room) { this.room = room; }

    public String getBatch() { return batch; }
    public void setBatch(String batch) { this.batch = batch; }

    public Teacher getTeacher() { return teacher; }
    public void setTeacher(Teacher teacher) { this.teacher = teacher; }

    public Admin getAdmin() { return admin; }
    public void setAdmin(Admin admin) { this.admin = admin; }
}