package com.scms.scms.repository;

import com.scms.scms.model.Fees;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FeesRepository extends JpaRepository<Fees, Long> {

    Fees findByCourse(String course);
}